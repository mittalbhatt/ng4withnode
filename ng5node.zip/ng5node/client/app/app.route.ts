import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HashLocationStrategy ,LocationStrategy } from '@angular/common';

import { SelectivePreloadingStrategy } from './selective-preloading-strategy';
import { NotFoundComponent } from './not-found/not-found.component';
import { IndexComponent } from './index/index.component';

const routes: Routes = [
{ path: "",    component: IndexComponent},
{ path: "admin", loadChildren: "app/admin/admin-layout/admin-layout.module#AdminLayoutModule" },
{ path: "**",    component: NotFoundComponent }
];
@NgModule({
  imports: [ RouterModule.forRoot(
      routes,
      { preloadingStrategy: SelectivePreloadingStrategy }
  )],
  exports: [ RouterModule ],
  providers: [
      { provide: LocationStrategy, useClass: HashLocationStrategy },
  ]
})
export class AppRoutingModule {}
