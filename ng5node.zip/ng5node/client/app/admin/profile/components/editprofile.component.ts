import { Component, OnInit, ElementRef, Input, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ProfileService } from '../service/profile.service';
import { Profile } from '../../../models/user';
import { ActivatedRoute } from '@angular/router';
import { ToasterService } from 'angular2-toaster';
import { ChangeProfileService } from '../../../shared/shared.service'
import * as globals from '../../../shared/globals';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

@Component ({
    selector: 'edit-profile',
    templateUrl: '../templates/editprofile.component.html',
    providers: [Modal]
})
export class EditProfileComponent implements OnInit {
    
    public model: Profile;
    public loading = "<div class='loader_container'><div class='loader'></div></div>";
    public submitLoader:string = '';
    
    public invalidFile = false;
    public invalidFilemsg = '';
    public profileDelete = false;

    @Input() multiple: boolean = false;
    @ViewChild('profile_image') inputEl: ElementRef;
    
    constructor (
        private toasterService: ToasterService, 
        private route: ActivatedRoute,
        private router: Router,
        private profileService: ProfileService,
        private changeProfileService: ChangeProfileService,
        public modal: Modal
        ) {
        // this.model = new Profile(this.model);
    }
    ngOnInit(){
        this.model = this.route.snapshot.data['profile'];
    }    
    onChange(event: EventTarget) {
        let eventObj: MSInputMethodContext = <MSInputMethodContext> event;
        let target: HTMLInputElement = <HTMLInputElement> eventObj.target;
        let files: FileList = target.files;
        this.model.file = files[0];
        if(this.model.file.size > globals.validImageSize )
        {
            this.invalidFile = true;
            this.invalidFilemsg = "File too large , max file size allowed 5MB";
            this.inputEl.nativeElement.value = "";
        }
        else if(globals.validImageExtension.indexOf(this.model.file.type) == -1)
        {
            this.invalidFile = true;
            this.invalidFilemsg = "File should be image only";
            this.inputEl.nativeElement.value = "";
        }
        else {
            this.invalidFile = false;
            this.invalidFilemsg = "";
        }
    }
    removeProfile() {
        this.inputEl.nativeElement.value = "";
        return false;
    }
    save(event: Event){
        this.submitLoader = this.loading;
        
        let inputEl: HTMLInputElement = this.inputEl.nativeElement;
        if(this.invalidFile)
        {
            event.preventDefault();
            this.submitLoader = '';
            return false;

        }
        let formData = new FormData();
        for(var key in this.model)
        {
            formData.append(key, this.model[key]);
        }
        formData.append('profileDelete',this.profileDelete);
        formData.append('profile_image',inputEl.files.item(0));
        this.profileService.saveProfile(formData)
            .subscribe(response => {
                var res = JSON.parse(JSON.stringify(response));
                if(res)
                {                    
                    this.profileService.getProfile().subscribe(response => {
                        if(response)
                        {
                            
                            if(res.error == true){
                                this.toasterService.pop('error', res.message, '');
                            } else {
                                this.toasterService.pop('success', res.message, '');
                            }
                            this.changeProfileService.change(response);
                            this.router.navigate(['/admin/profile']);
                        }
                        else
                        {
                            this.toasterService.pop('error','Some server error may occured','');
                            this.submitLoader = '';
                        }
                    });
                }
                else 
                {
                    this.toasterService.pop('error', res.message, 'Some server error may occured');
                    this.submitLoader = '';
                }
                
            });
    }
    removeProfileImage(){
        if(confirm("Are you sure to delete profile picture?")) {
            this.profileDelete = true;
        }
        else{
            this.profileDelete = false;
        }
    }

    imgPopup(imgUrl: any){
        this.modal.alert()
        .size('lg')
        .showClose(true)
        .footerClass('hidden')
        .body("<img src="+imgUrl+" width='100%'>")
        .open();
    }
}