import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import {Profile} from '../../../models/user';

import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';


@Component ({
    selector: 'view-profile',
    templateUrl: '../templates/viewprofile.component.html',
    providers: [Modal]
})
export class ViewProfileComponent implements OnInit {
    
    public profile: Profile;
    constructor(private route: ActivatedRoute , public modal: Modal) {
        
    }
    ngOnInit(){
        this.profile =  this.route.snapshot.data['profile'];
    }

    imgPopup(imgUrl: any){
        this.modal.alert()
        .size('lg')
        .showClose(true)
        .footerClass('hidden')
        .body("<img src="+imgUrl+" width='100%'>")
        .open();
    }
}