import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListCoachingComponent } from './components/listcoaching.component';
import { CoachingResolve } from './service/coaching.resolve';

const routes: Routes = [
    { path: "", component: ListCoachingComponent, resolve: { coachings: CoachingResolve } }
];

@NgModule ({
    imports: [ RouterModule.forChild(routes) ],
    exports: [ RouterModule ]
})
export class CoachingRoutingModule {}