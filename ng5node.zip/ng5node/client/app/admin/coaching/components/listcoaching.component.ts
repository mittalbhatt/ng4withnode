import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ToasterService } from 'angular2-toaster';
import { Coaching } from '../../../models/user';
import { CoachingService } from '../service/coaching.service';

declare var $: any; 
import _ from "lodash";

@Component ({
    selector: 'list-coaching',
    templateUrl: '../templates/coaching.component.html',
    providers: [Modal]
})

export class ListCoachingComponent implements OnInit { 
    
    public coachings: Coaching;
    public sessionMap: any = {
        '1': 'Greater than 100%', 
        '2': '100 - 98%', 
        '3': '97.9 - 95%',
        '4': '94.9% or less'
    };
    public loading = "<div class='loader_container'><div class='loader'></div></div>";
    public submitLoader:string = '';
    public editCoachingId: any;
    constructor(private toasterService: ToasterService, 
        private route: ActivatedRoute , 
        public modal: Modal,
        private coachingService: CoachingService) {
        
    }
    ngOnInit(){
        this.coachings =  this.route.snapshot.data['coachings'];
        $(function() {
			$('#listcoachings').DataTable({
				responsive: true
			});
		});
    }

    changeStatus(event,val)
    {  

        if(confirm('Are you sure, you want to edit these coaching tips?')){
            this.editCoachingId = val;
        }    
    }

    save(event,coaching){
        if(coaching['sprint_1_to_6_msg']!='' && coaching['sprint_7_or_more_msg']!='' && coaching['post_workout_msg']!=''){
            if(confirm('Are you sure, you want to update these coaching tips?')){
                this.submitLoader = this.loading;
                let formData = new FormData();
                for(var key in coaching)
                {
                    formData.append(key, coaching[key]);
                }
                console.log(coaching['sprint_7_or_more_msg']);
                this.coachingService.saveCoaching(formData)
                .subscribe(response => {
                    //console.log(res);
                    var res = JSON.parse(JSON.stringify(response));
                    if(!res.error){
                        this.toasterService.pop('success', res.message, '');
                        this.submitLoader = '';
                        this.editCoachingId = '';
                    } else {
                        this.toasterService.pop('error', res.message);
                        this.submitLoader = '';
                    }
                });
            }
        } else {
            this.toasterService.pop('error', 'Coaching tips are mandatory, please check empty fields.');
            this.submitLoader = '';
        }
    }
}