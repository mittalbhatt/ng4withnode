import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/shared.module';

import { ListCoachingComponent } from './components/listcoaching.component';
import { CoachingService } from './service/coaching.service';
import { CoachingResolve } from './service/coaching.resolve';

import { CoachingRoutingModule } from './coaching.routing';
import { ModalModule } from 'angular2-modal';
import { BootstrapModalModule } from 'angular2-modal/plugins/bootstrap';
    
@NgModule ({
    imports: [
        SharedModule,
        CoachingRoutingModule,
        ModalModule.forRoot(),
        BootstrapModalModule
    ],
    providers: [
        CoachingService,
        CoachingResolve
    ],
    declarations : [
        ListCoachingComponent
    ]
})
export class CoachingModule {}