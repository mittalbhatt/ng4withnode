import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

import * as globals from '../../../shared/globals';
import {Coaching} from '../../../models/user';

@Injectable()
export class CoachingService {
    private requestUrl = globals.requestUrl+'/admin/coaching';  // URL to web API

    constructor (private http: Http) {}

    getCoachings(): Observable<Coaching> {
      return this.http.get(this.requestUrl)
                      .map(this.extractData)
                      .catch(this.handleError);
    }

    private extractData(res: Response) {
        let body = res.json();
        return body.data || { };
    }

    saveCoaching(coaching): Observable<Coaching> {
        //console.log("trainer",trainer);
        return this.http.post(this.requestUrl+'/editcoaching', coaching)
                .map((res: Response) => {return res.json()})
                .catch(this.handleError);
    }

    private handleError (error: Response | any) {
    // In a real world app, you might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        return Observable.throw(errMsg);
    }
}