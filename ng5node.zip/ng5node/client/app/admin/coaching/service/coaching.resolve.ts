import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { CoachingService } from './coaching.service';


@Injectable()
export class CoachingResolve implements Resolve<any> {
  	
  constructor(private coachingService: CoachingService) {}
  
  resolve() {
    return this.coachingService.getCoachings();
  }
}
