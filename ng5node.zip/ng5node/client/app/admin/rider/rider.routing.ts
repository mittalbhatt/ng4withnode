import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListRiderComponent } from './components/listrider.component';
import { EditRiderComponent } from './components/editrider.component';
import { ListByTrainerRiderComponent } from './components/listbytrainer.component';
import { RiderResolve,DetailRiderResolve, RidersByTrainerResolve } from './service/rider.resolve';

const routes: Routes = [
    { path: "", component: ListRiderComponent, resolve: { riders: RiderResolve } },
    { path: "edit/:id", component: EditRiderComponent, resolve: { rider: DetailRiderResolve } },
    { path: "trainer/:id", component: ListByTrainerRiderComponent, resolve: { riders: RidersByTrainerResolve } }
];

@NgModule ({
    imports: [ RouterModule.forChild(routes) ],
    exports: [ RouterModule ]
})
export class RiderRoutingModule {}