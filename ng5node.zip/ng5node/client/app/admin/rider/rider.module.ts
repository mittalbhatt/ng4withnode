import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/shared.module';

import { ListRiderComponent } from './components/listrider.component';
import { EditRiderComponent } from './components/editrider.component';
import { ListByTrainerRiderComponent } from './components/listbytrainer.component';
import { RiderService } from './service/rider.service';
import { RiderResolve, DetailRiderResolve, RidersByTrainerResolve } from './service/rider.resolve';

import { RiderRoutingModule } from './rider.routing';
import { ModalModule } from 'angular2-modal';
import { BootstrapModalModule } from 'angular2-modal/plugins/bootstrap';
    
@NgModule ({
    imports: [
        SharedModule,
        RiderRoutingModule,
        ModalModule.forRoot(),
        BootstrapModalModule
    ],
    providers: [
        RiderService,
        RiderResolve,
        DetailRiderResolve,
        RidersByTrainerResolve
    ],
    declarations : [
        ListRiderComponent,
        EditRiderComponent,
        ListByTrainerRiderComponent
    ]
})
export class RiderModule {}