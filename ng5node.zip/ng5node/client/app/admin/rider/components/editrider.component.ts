import { Component, OnInit, ElementRef, Input, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RiderService } from '../service/rider.service';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ToasterService } from 'angular2-toaster';
import {Rider} from '../../../models/user';
import * as globals from '../../../shared/globals';

declare var $: any; 
import _ from "lodash";

@Component ({
    selector: 'edit-rider',
    templateUrl: '../templates/editrider.component.html',
    providers: [Modal]
})
export class EditRiderComponent implements OnInit {
    
    public rider: Rider;
    public loading = "<div class='loader_container'><div class='loader'></div></div>";
    public submitLoader:string = '';
    public rider_height_feet = [4,5,6];
    public rider_height_inch = Array(12).fill(0).map((x,i)=>i);
    public invalidFile = false;
    public invalidFilemsg = '';
    public imageDelete = false; 

    @Input() multiple: boolean = false;
    @ViewChild('profile_image') inputEl: ElementRef;

    constructor(
        private toasterService: ToasterService, 
        private route: ActivatedRoute , 
        public modal: Modal,
        private riderService: RiderService
    ) { }

    ngOnInit(){
        this.rider =  this.route.snapshot.data['rider'];
        if(this.rider.height){
            var num = this.rider.height;
            var str=num.toString();
            var numarray=str.split('.');
            var a=new Array();
            a=numarray;
            this.rider.height_feet = (a[0])?a[0]:'';
            this.rider.height_inch = (a[1])?a[1]:'';
        } else {
            this.rider.height_feet = '';
            this.rider.height_inch = ''; 
        }
    }

    onChange(event: EventTarget) {
        let eventObj: MSInputMethodContext = <MSInputMethodContext> event;
        let target: HTMLInputElement = <HTMLInputElement> eventObj.target;
        let files: FileList = target.files;
        this.rider.file = files[0];
        if(this.rider.file.size > globals.validImageSize )
        {
            this.invalidFile = true;
            this.invalidFilemsg = "File too large , max file size allowed 5MB";
            this.inputEl.nativeElement.value = "";
        }
        else if(globals.validImageExtension.indexOf(this.rider.file.type) == -1)
        {
            this.invalidFile = true;
            this.invalidFilemsg = "File should be image only";
            this.inputEl.nativeElement.value = "";
        }
        else {
            this.invalidFile = false;
            this.invalidFilemsg = "";
        }
    }

    removeProfileImage(){
        if(confirm("Are you sure to delete profile picture?")) {
            this.imageDelete = true;
        }
        else{
            this.imageDelete = false;
        }
    }

    save(event: Event){

        this.submitLoader = this.loading;
        let inputEl: HTMLInputElement = this.inputEl.nativeElement;
        if(this.invalidFile)
        {
            event.preventDefault();
            this.submitLoader = '';
            return false;

        }

        let formData = new FormData();
        for(var key in this.rider)
        {
            formData.append(key, this.rider[key]);
        }

        formData.append('profileDelete',this.imageDelete);
        formData.append('profile_image',inputEl.files.item(0));
        //console.log("formData",formData);
        this.riderService.saveRider(formData)
        .subscribe(response => {
            //console.log(res);
            var res = JSON.parse(JSON.stringify(response));
            if(!res.error){

                this.toasterService.pop('success', res.message, '');
                this.submitLoader = '';
            } else {
                this.toasterService.pop('error', res.message, 'Some server error may occured');
                this.submitLoader = '';
            }
        });
    }
    
    imgPopup(imgUrl: any){
        this.modal.alert()
        .size('lg')
        .showClose(true)
        .footerClass('hidden')
        .body("<img src="+imgUrl+" width='100%'>")
        .open();
    }

}