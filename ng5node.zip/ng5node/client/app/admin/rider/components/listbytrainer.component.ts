import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ToasterService } from 'angular2-toaster';
import { Rider } from '../../../models/user';
import { RiderService } from '../service/rider.service';

declare var $: any; 
import _ from "lodash";

@Component ({
    selector: 'list-by-trainer',
    templateUrl: '../templates/listbytrainer.component.html',
    providers: [Modal]
})

export class ListByTrainerRiderComponent implements OnInit {
    
    public riders: Rider;
    public indexOfClickedRow: number;
    public trainer_details: string;
    public trainer_id: number;

    constructor(private toasterService: ToasterService, 
        private route: ActivatedRoute , 
        public modal: Modal,
        private riderService: RiderService) {
        
    }
    ngOnInit(){
        this.riders =  this.route.snapshot.data['riders'];
        $(function() {
			$('#lisriders').DataTable({
				responsive: true
			});
		});
    }

    changeStatus(event,rider)
    {       
            let status = rider.active ? true : false;
            this.riderService.changeStatus(status,rider.rider_id)
                .subscribe(response => {
                    var res = JSON.parse(JSON.stringify(response));
                    if(!res.error)
                    {   
                        this.toasterService.pop('success', res.message, '');
                    }
                    else 
                    {   
                        rider.active = !status;
                        this.toasterService.pop('error', res.message, '');
                    }
                    
                });
            
    }

}