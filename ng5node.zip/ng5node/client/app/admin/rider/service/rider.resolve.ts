import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { RiderService } from './rider.service';


@Injectable()
export class RiderResolve implements Resolve<any> {
  	
  constructor(private riderService: RiderService) {}
  
  resolve() {
    return this.riderService.getRiders();
  }
}

@Injectable()
export class DetailRiderResolve implements Resolve<any> {
  
  constructor(private riderService: RiderService) {}
  
  resolve(route: ActivatedRouteSnapshot) {
     return this.riderService.getRider(route.paramMap.get('id'));
  }
}

@Injectable()
export class RidersByTrainerResolve implements Resolve<any> {

  constructor(private riderService: RiderService) {}
  
  resolve(route: ActivatedRouteSnapshot) {
     return this.riderService.getRiderByTrainer(route.paramMap.get('id'));
  }

}