import { NgModule } from '@angular/core';

import { SharedModule } from '../../shared/shared.module';
import { ToasterModule } from 'angular2-toaster';
import { LoginComponent } from './components/login.component';
import { LogoutComponent } from './components/logout.component';
import { ForgotPasswordComponent }from './components/forgotpassword.component';
import { ResetPasswordComponent } from './components/resetpassword.component';
import { EmailVerificationComponent } from './components/emailverification.component';
import { IncludeComponent } from './components/include.component';

@NgModule({
  imports: [
    ToasterModule,
    SharedModule
  ],
  declarations: [
    LoginComponent, 
    LogoutComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    EmailVerificationComponent,
    IncludeComponent
  ]
})
export class AuthModule { }
