import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AdminAuthService } from '../service/adminauth.service';
import { CookieService } from 'angular2-cookie/core';
import { ToasterService } from 'angular2-toaster';

@Component({
    selector: 'login',
    templateUrl: '../templates/login.component.html',
})

export class LoginComponent implements OnInit {
    model: any = {};
    loading = false;
    
    constructor(
        private router: Router,
        private cookieStorage: CookieService,
        private authenticationService: AdminAuthService,
        private toasterService: ToasterService) {
        this.model.useremail = localStorage.getItem('adminRememberEmail');
        this.model.rememberme = localStorage.getItem('adminRememberMe');
    }

    ngOnInit() {
        if (localStorage.getItem('adminUserSession')) {
            this.router.navigate(['/admin']);
        }
    }
    ngAfterViewInit(){
        if(localStorage.getItem('admin-forgotpassword-success'))
        {
            this.toasterService.pop('success', localStorage.getItem('admin-forgotpassword-success'), '');
            localStorage.removeItem('admin-forgotpassword-success');
        }
        if(localStorage.getItem('admin-resetpassword-success'))
        {
            this.toasterService.pop('success', localStorage.getItem('admin-resetpassword-success'), '');
            localStorage.removeItem('admin-resetpassword-success');
        }
    }
    login() {
        this.loading = true;
        
        this.authenticationService.login(this.model.useremail, this.model.password, this.model.rememberme)
            .subscribe(response => {
                var res = JSON.parse(JSON.stringify(response));

                if(res.newToken && res.error == false)
                {
                    this.router.navigate(['/admin']);
                }
                else {
                    this.toasterService.pop('error', res.message, '');
                    this.loading = false;
                }
            });
                
        
    }
    
}
