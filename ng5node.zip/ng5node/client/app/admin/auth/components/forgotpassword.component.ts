import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AdminAuthService } from '../service/adminauth.service';
import { CookieService } from 'angular2-cookie/core';
import { ToasterService } from 'angular2-toaster';

@Component({
    templateUrl: '../templates/forgotpassword.component.html'
})

export class ForgotPasswordComponent implements OnInit {
    model: any = {};
    public loading = "<div class='loader_container'><div class='loader'></div></div>";
    public submitLoader:string = '';
    
    constructor(
        private router: Router,
        private cookieStorage: CookieService,
        private toasterService: ToasterService,
        private authenticationService: AdminAuthService) { }

    ngOnInit() {
        if (localStorage.getItem('adminUserSession')) {
            this.router.navigate(['/admin']);
        }
    }

    forgotPassword() {
        this.submitLoader = this.loading;
            this.authenticationService.forgotpassword(this.model.useremail)
                .subscribe(response => {
                    var result = JSON.parse(JSON.stringify(response));
                    if(result)
                    {
                        if (!result.error) {
                            localStorage.setItem('admin-forgotpassword-success', result.message);
                            // this.toasterService.pop('success', result.message, '');
                            this.submitLoader = '';
                            this.router.navigate(['/admin/login']);
                        } else {
                            this.toasterService.pop('error', result.message, '');
                            this.submitLoader = '';
                        }
                    }
            });
    }
}
