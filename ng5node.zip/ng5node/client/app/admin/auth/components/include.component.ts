import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';

@Component({
	template:'',
    selector:'include-styles',
    // styleUrls:['../../../../assets/vendor/style.css',
				// '../../../../assets/vendor/adminlte/bootstrap/css/bootstrap.min.css',
				// '../../../../assets/vendor/font-awesome/css/font-awesome.min.css',
				// '../../../../assets/vendor/adminlte/dist/css/AdminLTE.min.css',
				// '../../../../assets/vendor/adminlte/dist/css/skins/_all-skins.min.css',
				// '../../../../assets/vendor/adminlte/plugins/iCheck/flat/blue.css'],
				encapsulation: ViewEncapsulation.None
    
})

export class IncludeComponent implements OnInit {
    
    constructor(
        private router: Router
        ){ }

    ngOnInit() {
        
    }    
}
