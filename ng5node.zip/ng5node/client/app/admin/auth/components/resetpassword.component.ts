import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

import { AdminAuthService } from '../service/adminauth.service';
import {CookieService} from 'angular2-cookie/core';
import { ToasterService } from 'angular2-toaster';

@Component({
    templateUrl: '../templates/resetpassword.component.html'
})

export class ResetPasswordComponent implements OnInit {
    model: any = {};
    loading = false;
    token = '';
    
    constructor(
        private router: Router,
        private cookieStorage: CookieService,
        private toasterService: ToasterService,
        private activatedRoute: ActivatedRoute,
        private authenticationService: AdminAuthService
        ) { }

    ngOnInit() {
        // reset login status
        if (localStorage.getItem('adminUserSession')) {
            this.router.navigate(['/admin']);
        }
        this.activatedRoute.params.subscribe((params: Params) => {
            this.token = params['token'];
          });
    }

    resetPassword() {
        this.loading = true;
            this.authenticationService.resetpassword(this.token, this.model.password)
                .subscribe(response => {
                    var result = JSON.parse(JSON.stringify(response));
                    if(result)
                    {
                        if (!result.error) {

                            if(result.is_admin == true){
                                localStorage.setItem('admin-resetpassword-success', result.message);
                                // this.toasterService.pop('success', result.message, '');
                                this.loading = false;
                                this.router.navigate(['/admin/login']);    
                            } else {
                                this.toasterService.pop('success', result.message, '');
                                this.loading = false;
                            }
                            
                        } else {
                            this.toasterService.pop('error', result.message, '');
                            this.loading = false;
                        }
                    }
            });
    }
}
