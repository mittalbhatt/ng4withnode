import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

import { AdminAuthService } from '../service/adminauth.service';

@Component({
    templateUrl: '../templates/emailverification.component.html'
})

export class EmailVerificationComponent implements OnInit {
    
    public loading = false;
    public token = '';
    public message = '';

    constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private authenticationService: AdminAuthService
        ) { }

    ngOnInit() {
        
        this.activatedRoute.params.subscribe((params: Params) => {
           this.token = params['token'];
           
           if(this.token){

               this.authenticationService.emailverification(this.token)
                .subscribe(response => {
                    var result = JSON.parse(JSON.stringify(response));
                    if(result)
                    {
                        this.loading = false;
                        this.message = result.message;
                    }
                });

           } else {
               this.message = "Invalid Token";
           }

        });
    }

}
