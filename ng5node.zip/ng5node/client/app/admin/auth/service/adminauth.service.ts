﻿import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { CookieService } from 'angular2-cookie/core';
import * as globals from '../../../shared/globals';

@Injectable()
export class AdminAuthService {
    
    private requestUrl = globals.requestUrl;
    private options: RequestOptions;
    constructor(private http?: Http, private cookieStorage?: CookieService) {
                
        this.options = new RequestOptions({
        	headers: new Headers({ 'Content-Type': 'application/json;charset=UTF-8' }) 
        });
    }

    login(useremail: string, password: string, rememberme: boolean): Observable<string> {
        
        let now = new Date();
        let exp = new Date(now.getTime() + (6*60*60*1000)); 

        let options = new RequestOptions({
        	headers: new Headers({ 'Content-Type': 'application/json;charset=UTF-8' }) 
        });
        let user = {username: {email:useremail, isadmin: 1 }, password: password, grant_type: 'password'};
        let url = this.requestUrl+'/admin/signin';
        
        return this.http.post(url,JSON.stringify(user), options)
            .map((response: Response) => {
                let res = response.json();
                // login successful if there's a jwt token in the response
                let token = res && res.newToken;
                if (token) {
                // set token property
                    localStorage.setItem('bearerToken', res.newToken);
                    
                    localStorage.setItem('adminUserSession', res);

                    if(rememberme)
                    {
                        localStorage.setItem('adminRememberMe', 'true');
                        localStorage.setItem('adminRememberEmail', useremail);
                    }
                    else
                    {
                        localStorage.removeItem('adminRememberMe');
                        localStorage.removeItem('adminRememberEmail');
                    }
                    return res;
                } else {
                    return res;
                }

            }).catch(this.handleError);
    }
    logout(): void {
        if(!localStorage.getItem('adminRememberMe'))
        {
            localStorage.removeItem('adminRememberMe');
            localStorage.removeItem('adminRememberEmail');
        }
        localStorage.removeItem('adminUserSession');
        localStorage.removeItem('adminToken');
        this.cookieStorage.removeAll();
    }
    
    forgotpassword(useremail: string): Observable<string> {
        let url = this.requestUrl+'/admin/forgotpassword';
        return this.http.post(url, JSON.stringify({ useremail: useremail}), this.options)
            .map((response: Response) => {
                // login successful if there's a jwt token in the response
                let status = response.json() && response.json().status;
                return response.json();
            }).catch(this.handleError);
    }
    
    resetpassword(token: string, password: string): Observable<string> {
        let url = this.requestUrl+'/admin/resetpassword';
        return this.http.post(url, JSON.stringify({token: token, password: password}), this.options)
            .map((response: Response) => {
                return response.json();
        }).catch(this.handleError);
    }

    emailverification(token: string): Observable<string> {
        let url = this.requestUrl+'/admin/emailverification';
        return this.http.post(url, JSON.stringify({token: token}), this.options)
            .map((response: Response) => {
                return response.json();
        }).catch(this.handleError);
    }
    
    private handleError (error: Response | any) {
    // In a real world app, you might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {console.log(error);
          const body = error.json() || '';
          const err = body.error || JSON.stringify(body);
          errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
          errMsg = error.message ? error.message : error.toString();
        }
        console.log(errMsg);
        return Observable.throw(errMsg);
    }
}