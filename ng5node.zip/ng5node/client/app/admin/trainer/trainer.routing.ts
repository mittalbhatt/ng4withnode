import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListTrainerComponent } from './components/listtrainer.component';
import { EditTrainerComponent } from './components/edittrainer.component';
import { TrainerResolve,DetailTrainerResolve } from './service/trainer.resolve';

const routes: Routes = [
    { path: "", component: ListTrainerComponent, resolve: { trainers: TrainerResolve } },
    { path: "edit/:id", component: EditTrainerComponent, resolve: { trainer: DetailTrainerResolve } }
];

@NgModule ({
    imports: [ RouterModule.forChild(routes) ],
    exports: [ RouterModule ]
})
export class TrainerRoutingModule {}