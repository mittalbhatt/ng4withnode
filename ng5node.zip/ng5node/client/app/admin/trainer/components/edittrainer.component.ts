import { Component, OnInit, ElementRef, Input, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TrainerService } from '../service/trainer.service';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ToasterService } from 'angular2-toaster';
import {Profile} from '../../../models/user';
import * as globals from '../../../shared/globals';

declare var $: any; 
import _ from "lodash";

@Component ({
    selector: 'edit-trainer',
    templateUrl: '../templates/edittrainer.component.html',
    providers: [Modal]
})
export class EditTrainerComponent implements OnInit {
    
    public trainer: Profile;
    public loading = "<div class='loader_container'><div class='loader'></div></div>";
    public submitLoader:string = '';
    
    public invalidFile = false;
    public invalidFilemsg = '';
    public imageDelete = false; 

    @Input() multiple: boolean = false;
    @ViewChild('profile_image') inputEl: ElementRef;

    constructor(
        private toasterService: ToasterService, 
        private route: ActivatedRoute , 
        public modal: Modal,
        private trainerService: TrainerService
    ) { }

    ngOnInit(){
        this.trainer =  this.route.snapshot.data['trainer'];
        // console.log(this.trainer);
    }

    onChange(event: EventTarget) {
        let eventObj: MSInputMethodContext = <MSInputMethodContext> event;
        let target: HTMLInputElement = <HTMLInputElement> eventObj.target;
        let files: FileList = target.files;
        this.trainer.file = files[0];
        if(this.trainer.file.size > globals.validImageSize )
        {
            this.invalidFile = true;
            this.invalidFilemsg = "File too large , max file size allowed 5MB";
            this.inputEl.nativeElement.value = "";
        }
        else if(globals.validImageExtension.indexOf(this.trainer.file.type) == -1)
        {
            this.invalidFile = true;
            this.invalidFilemsg = "File should be image only";
            this.inputEl.nativeElement.value = "";
        }
        else {
            this.invalidFile = false;
            this.invalidFilemsg = "";
        }
    }

    removeProfileImage(){
        if(confirm("Are you sure to delete profile picture?")) {
            this.imageDelete = true;
        }
        else{
            this.imageDelete = false;
        }
    }

    save(event: Event){

        this.submitLoader = this.loading;
        let inputEl: HTMLInputElement = this.inputEl.nativeElement;
        if(this.invalidFile)
        {
            event.preventDefault();
            this.submitLoader = '';
            return false; 

        }

        let formData = new FormData();
        for(var key in this.trainer)
        {
            formData.append(key, this.trainer[key]);
        }

        formData.append('profileDelete',this.imageDelete);
        formData.append('profile_image',inputEl.files.item(0));
        //console.log("formData",formData);
        this.trainerService.saveTrainer(formData)
        .subscribe(response => {
            //console.log(res);
            var res = JSON.parse(JSON.stringify(response));
            if(!res.error){

                this.toasterService.pop('success', res.message, '');
                this.submitLoader = '';
            } else {
                this.toasterService.pop('error', res.message, 'Some server error may occured');
                this.submitLoader = '';
            }
        });
    }
    
    imgPopup(imgUrl: any){
        this.modal.alert()
        .size('lg')
        .showClose(true)
        .footerClass('hidden')
        .body("<img src="+imgUrl+" width='100%'>")
        .open();
    }

}