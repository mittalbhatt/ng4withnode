import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ToasterService } from 'angular2-toaster';
import {Profile} from '../../../models/user';
import { TrainerService } from '../service/trainer.service';

declare var $: any; 
import _ from "lodash";

@Component ({
    selector: 'view-trainer',
    templateUrl: '../templates/listtrainer.component.html',
    providers: [Modal]
})

export class ListTrainerComponent implements OnInit {
    
    public trainers: Profile;
    public indexOfClickedRow: number;

    constructor(private toasterService: ToasterService, 
        private route: ActivatedRoute , 
        public modal: Modal,
        private trainerService: TrainerService) {
        
    }
    ngOnInit(){
        this.trainers =  this.route.snapshot.data['trainers'];

        $(function() {
			$('#listtrainer').DataTable({
				responsive: true
			});
		});
    }

    changeStatus(event,user)
    {       
            let status = user.active ? true : false;
            this.trainerService.changeStatus(status,user.id)
                .subscribe(response => {
                    var res = JSON.parse(JSON.stringify(response));
                    if(!res.error)
                    {   
                        this.toasterService.pop('success', res.message, '');
                    }
                    else 
                    {   
                        user.active = !status;
                        this.toasterService.pop('error', res.message, '');
                    }
                    
                });
            
    }

}