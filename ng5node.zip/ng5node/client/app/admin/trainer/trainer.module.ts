import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/shared.module';

import { ListTrainerComponent } from './components/listtrainer.component';
import { EditTrainerComponent } from './components/edittrainer.component';
import { TrainerService } from './service/trainer.service';
import { TrainerResolve,DetailTrainerResolve } from './service/trainer.resolve';

import { TrainerRoutingModule } from './trainer.routing';
import { ModalModule } from 'angular2-modal';
import { BootstrapModalModule } from 'angular2-modal/plugins/bootstrap';
    
@NgModule ({
    imports: [
        SharedModule,
        TrainerRoutingModule,
        ModalModule.forRoot(),
        BootstrapModalModule
    ],
    providers: [
        TrainerService,
        TrainerResolve,
        DetailTrainerResolve
    ],
    declarations : [
        ListTrainerComponent,
        EditTrainerComponent
    ]
})
export class TrainerModule {}