import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

import * as globals from '../../../shared/globals';
import {Profile} from '../../../models/user';

@Injectable()
export class TrainerService {
    private requestUrl = globals.requestUrl+'/admin/trainer';  // URL to web API

    constructor (private http: Http) {}

    getTrainers(): Observable<Profile> {
      return this.http.get(this.requestUrl)
                      .map(this.extractData)
                      .catch(this.handleError);
    }

    getTrainer(id: string): Observable<Profile> {
      return this.http.get(this.requestUrl +'/'+ id)
                      .map(this.extractData)
                      .catch(this.handleError);
    }

    changeStatus(active: boolean, id: number): Observable<string>{
        return this.http.post(this.requestUrl+'/status',{active: active, id: id})
                        .map((res: Response) => {return res.json()})
                        .catch(this.handleError);
    }

    private extractData(res: Response) {
        let body = res.json();
        return body.data || { };
    }

    saveTrainer(trainer): Observable<Profile> {
        //console.log("trainer",trainer);
        return this.http.post(this.requestUrl+'/edittrainer', trainer)
                .map((res: Response) => {return res.json()})
                .catch(this.handleError);
    }

    private handleError (error: Response | any) {
    // In a real world app, you might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.log(errMsg);
        return Observable.throw(errMsg);
    }
}