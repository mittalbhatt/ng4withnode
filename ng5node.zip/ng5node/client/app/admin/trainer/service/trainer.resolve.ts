import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { TrainerService } from './trainer.service';


@Injectable()
export class TrainerResolve implements Resolve<any> {
  	
  constructor(private trainerService: TrainerService) {}
  
  resolve() {
    return this.trainerService.getTrainers();
  }
}

@Injectable()
export class DetailTrainerResolve implements Resolve<any> {
  
  constructor(private trainerService: TrainerService) {}
  
  resolve(route: ActivatedRouteSnapshot) {
     return this.trainerService.getTrainer(route.paramMap.get('id'));
  }
}