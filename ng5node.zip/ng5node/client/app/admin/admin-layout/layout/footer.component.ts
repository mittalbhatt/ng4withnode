import { Component, OnInit } from '@angular/core';
declare var $:any;

@Component({
  selector: 'admin-footer',
  templateUrl: './footer.component.html',
})
export class FooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
