import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import {Profile} from '../../../models/user';
import { ChangeProfileService } from '../../../shared/shared.service';

@Component({
  selector: 'admin-header',
  templateUrl: './header.component.html',
})
export class HeaderComponent implements OnInit {

  public profile_details: Profile;

  constructor(private route: ActivatedRoute, private changeProfileService: ChangeProfileService, private router: Router) { }

  ngOnInit() {
    this.profile_details =  this.route.snapshot.data['profile'];
    this.changeProfileService.getEmittedValue()
      .subscribe(profile => this.profile_details=profile);
  }

  logout()
  {
  	if(confirm('Are you sure you want to end the session?')){
  		this.router.navigate(['/admin/logout']);
  	}
  }
}
