import { ViewEncapsulation, Component, OnInit } from '@angular/core';
import { ToasterService, ToasterConfig } from 'angular2-toaster';
import { Router, NavigationStart, NavigationEnd, NavigationError, NavigationCancel, RoutesRecognized } from '@angular/router';

@Component({
  encapsulation: ViewEncapsulation.None,
  selector: 'app-layout',
  templateUrl: './layout.component.html'
})
export class LayoutComponent implements OnInit {

  routerOutlet: string;

  constructor(private toasterService: ToasterService,private router: Router) { 
    router.events
    .filter(event => event instanceof NavigationStart)
    .subscribe((event:NavigationStart) => {
      this.routerOutlet = '<div class="loader_container"><div class="loader"></div></div>';  
    });

    router.events
    .filter(event => event instanceof NavigationEnd)
    .subscribe((event:NavigationEnd) => {
      this.routerOutlet = '';  
    });

    router.events
    .filter(event => event instanceof NavigationError)
    .subscribe((event:NavigationError) => {
      this.routerOutlet = '';
    });

    router.events
    .filter(event => event instanceof NavigationCancel)
    .subscribe((event:NavigationCancel) => {
      this.routerOutlet = '';
    });
  }
  
  public toasterconfig : ToasterConfig = 
        new ToasterConfig({
            showCloseButton: true, 
            tapToDismiss: false, 
            timeout: 5000,
            limit: 5,
            mouseoverTimerStop: true
        });
  ngOnInit() {
    
  }

  ngAfterViewInit(){
    
    // Collapse box
    $('.box-typical-dashboard').each(function(){
      var parent = $(this),
        btnCollapse = parent.find('.action-btn-collapse');

      btnCollapse.click(function(){
        if (parent.hasClass('box-typical-collapsed')) {
          parent.removeClass('box-typical-collapsed');
        } else {
          parent.addClass('box-typical-collapsed');
        }
      });
    });

    // Full screen box
    $('.box-typical-dashboard').each(function(){
      var parent = $(this),
        btnExpand = parent.find('.action-btn-expand'),
        classExpand = 'box-typical-full-screen';

      btnExpand.click(function(){
        if (parent.hasClass(classExpand)) {
          parent.removeClass(classExpand);
          $('html').css('overflow','auto');
        } else {
          parent.addClass(classExpand);
          $('html').css('overflow','hidden');
        }
        dashboardBoxHeight();
      });
    });

    // Calculate height
    function dashboardBoxHeight() {
      $('.box-typical-dashboard').each(function(){
        var parent = $(this),
          header = parent.find('.box-typical-header'),
          body = parent.find('.box-typical-body');
        body.height(parent.outerHeight() - header.outerHeight());
      });
    }

    dashboardBoxHeight();

    $(window).resize(function(){
      dashboardBoxHeight();
    });

    // Left mobile menu
    $('.hamburger').click(function(){
      if ($('body').hasClass('menu-left-opened')) {
        $(this).removeClass('is-active');
        $('body').removeClass('menu-left-opened');
        $('html').css('overflow','auto');
      } else {
        $(this).addClass('is-active');
        $('body').addClass('menu-left-opened');
        $('html').css('overflow','hidden');
      }
    });

    $('.mobile-menu-left-overlay').click(function(){
      $('.hamburger').removeClass('is-active');
      $('body').removeClass('menu-left-opened');
      $('html').css('overflow','auto');
    });

    // Right mobile menu
    $('.site-header .burger-right').click(function(){
      if ($('body').hasClass('menu-right-opened')) {
        $('body').removeClass('menu-right-opened');
        $('html').css('overflow','auto');
      } else {
        $('.hamburger').removeClass('is-active');
        $('body').removeClass('menu-left-opened');
        $('body').addClass('menu-right-opened');
        $('html').css('overflow','hidden');
      }
    });

    $('.mobile-menu-right-overlay').click(function(){
      $('body').removeClass('menu-right-opened');
      $('html').css('overflow','auto');
    });

  }

}
