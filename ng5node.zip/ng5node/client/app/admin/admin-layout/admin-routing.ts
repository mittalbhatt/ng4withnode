import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LayoutComponent } from './layout/layout.component';
import { NotFoundComponent } from './not-found/not-found.component';

import { LoginComponent } from '../auth/components/login.component';
import { LogoutComponent } from '../auth/components/logout.component';
import { ForgotPasswordComponent }from '../auth/components/forgotpassword.component';
import { ResetPasswordComponent } from '../auth/components/resetpassword.component';
import { EmailVerificationComponent } from '../auth/components/emailverification.component';
import { AdminAuthGuard } from '../guard/auth.guard';

import { ProfileResolve } from '../profile/service/profile.resolve';

const routes: Routes = [
    { path: "login", component: LoginComponent },
    { path: "logout", component: LogoutComponent },
    { path: "forgotpassword", component: ForgotPasswordComponent },
    { path: "resetpassword/:token", component: ResetPasswordComponent },
    { path: "emailverification/:token", component: EmailVerificationComponent },
    { 
      path: "",
      canActivate: [AdminAuthGuard],
      component: LayoutComponent, resolve: { profile: ProfileResolve },
      children:[
        { path: "", loadChildren:"app/admin/dashboard/dashboard.module#DashboardModule" },
        { path: "profile", loadChildren: "app/admin/profile/profile.module#ProfileModule" },
        { path: "trainer", loadChildren: "app/admin/trainer/trainer.module#TrainerModule" },
        { path: 'rider', loadChildren: "app/admin/rider/rider.module#RiderModule" },
        { path: 'coaching_tips', loadChildren: "app/admin/coaching/coaching.module#CoachingModule" }
      ]
    },
    { path: '**',    component: NotFoundComponent }
];
@NgModule({
  imports: [ RouterModule.forChild(routes) ],
  exports: [ RouterModule ]
})
export class AdminRoutingModule {

  constructor(){
  }
}
