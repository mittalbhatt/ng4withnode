import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LayoutComponent } from './layout/layout.component';
import { HeaderComponent } from './layout/header.component';
import { MenuComponent } from './layout/menu.component';
import { FooterComponent } from './layout/footer.component';
import { AdminRoutingModule } from "./admin-routing";
import { NotFoundComponent } from './not-found/not-found.component';
import { ToasterModule } from 'angular2-toaster';

import { AuthModule } from '../auth/auth.module';

import { ProfileResolve } from '../profile/service/profile.resolve';
import { ProfileService } from '../profile/service/profile.service';
import { ChangeProfileService } from '../../shared/shared.service'

import { AdminAuthGuard } from '../guard/auth.guard'

@NgModule({
    imports: [
        CommonModule,
        AdminRoutingModule,
        AuthModule,
        ToasterModule
    ],
    declarations: [
        LayoutComponent,
        HeaderComponent,
        MenuComponent,
        FooterComponent,
        NotFoundComponent
    ],
    providers: [
        ProfileResolve,
        ProfileService,
        AdminAuthGuard,
        ChangeProfileService
    ]
})
export class AdminLayoutModule { }
