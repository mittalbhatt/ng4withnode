'use strict';
import { environment } from '../../environments/environment';

export const requestUrl = environment.requestUrl;
export const validImageExtensions = ['.png','.jpg','.jpeg','gif'];
export const validImageExtension = ['image/png','image/jpg','image/jpeg','image/gif'];
export const validImageSize = 5000000;
export const itemsPerPage = 10;
export const itemsPerPageArray = [10, 20, 30, 40, 50];