import { NgModule } from '@angular/core';

import '../../assets/theme/js/app.js';

@NgModule({
})
export class ImportModule { }