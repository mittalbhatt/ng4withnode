import { NgModule }            from '@angular/core';
import { CommonModule }        from '@angular/common';
import { FormsModule }         from '@angular/forms';
import { RouterModule }        from '@angular/router';
import { UiSwitchModule } from 'ng2-ui-switch';

@NgModule({
  imports: [ 
            CommonModule,
            UiSwitchModule
          ],
  declarations: [ 
          ],
  exports: [ 
            FormsModule,
            RouterModule,
            CommonModule,
            UiSwitchModule
          ]
})
export class SharedModule { }