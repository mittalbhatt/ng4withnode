import { BaseRequestOptions, Headers, RequestMethod } from "@angular/http";
import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { CookieService } from "angular2-cookie/core";
import {Location, LocationStrategy, PathLocationStrategy} from '@angular/common';

@Injectable()
export class DefaultRequestOptions extends BaseRequestOptions {
    private _headers:Headers;
    constructor(private router:Router, private cookieStorage: CookieService, private location: Location) {
        super();
    }
    get headers()
    {
        var headersCopy = new Headers(this._headers ? this._headers.values() : null);
        if (this.method != 'GET' && this.method != RequestMethod.Get)
            headersCopy.set('Content-Type', 'application/json;charset=UTF-8');

        if ((!this._headers || !this._headers.has('Authorization')))
        {
            let bearerToken = ''; 
         
            bearerToken = localStorage.getItem('bearerToken');

            headersCopy.set('Authorization', 'JWT ' + bearerToken);
        }
        return headersCopy;
    }

    set headers(value:Headers)
    {
        this._headers = value;
    }
}