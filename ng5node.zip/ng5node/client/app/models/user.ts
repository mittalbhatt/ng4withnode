export class Profile {
    email:string;
    firstname:string;
    lastname:string;
    changePassword: boolean;
    newpassword: string;
    
    mobile_no: string;
    is_fb_user: boolean;
    fb_id: boolean;

    profileimage:string;
    profileimagethumb:string;
    profile_image: string;
    
    file: File;

    constructor(src:Profile) {
        for(var key in src)
        {
            this[key] = src[key];
        }
    }
}

export class Rider {
    email:string;
    firstname:string;
    lastname:string;
    mobile_no: string;
    height: number;
    weight: number;
    age: number;
    trainer_details: object;
    height_feet: string;
    height_inch: string;
    file: File;
    
    constructor(src:Rider) {
        for(var key in src)
        {
            this[key] = src[key];
        }
    }
}

export class Coaching {
    workout_type: string;
    session_avg: string;
    sprint_1_to_6_msg: string;
    sprint_7_or_more_msg: string;
    post_workout_msg: string;
}