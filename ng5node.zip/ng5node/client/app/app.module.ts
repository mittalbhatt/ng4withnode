import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
// import { FormsModule } from '@angular/forms';
import { HttpModule, RequestOptions } from '@angular/http';
import { Router} from '@angular/router';

import { AppRoutingModule }     from './app.route';

import { SelectivePreloadingStrategy } from './selective-preloading-strategy';

import { CookieService, CookieOptions } from 'angular2-cookie/core';

import { AppComponent } from './app.component';
import { NotFoundComponent } from './not-found/not-found.component';

import { DefaultRequestOptions } from './common/service/default-request-options.service';
import { AdminAuthService } from './admin/auth/service/adminauth.service';
import { IndexComponent } from './index/index.component';

@NgModule({
    declarations: [
        AppComponent,
        NotFoundComponent,
        IndexComponent
    ],
    imports: [
        BrowserModule,
        // FormsModule,
        HttpModule,
        AppRoutingModule
    ],
    providers: [
        SelectivePreloadingStrategy,
        CookieService,
        AdminAuthService,
        { provide: CookieOptions, useValue: {} },
        { provide: RequestOptions, useClass: DefaultRequestOptions }
        
    ],
  bootstrap: [AppComponent]
})
export class AppModule { }
