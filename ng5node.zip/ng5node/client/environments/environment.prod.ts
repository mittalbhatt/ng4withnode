export const environment = {
  production: true,
  requestUrl: 'http://35.153.174.163:9090',
  siteUrl: 'http://35.153.174.163/dist'
};
