// =======================
// get the packages we need
// =======================
var express     = require('express');
var app         = express();
var bodyParser  = require('body-parser');
var mysql       = require('mysql');
var cookieParser = require('cookie-parser');
var jwt      = require('jsonwebtoken'); // used to create, sign, and verify tokens
var config   = require('./server/config/sequelize'); // get our config file
var path = require('path');
var session = require('express-session');
var expressValidator = require('express-validator');
var cors = require('cors');

app.use(cors());
var port = process.env.PORT || 9090; // used to create, sign, and verify tokens

app.set('superSecret', config.secret); // secret variable
app.use(session({
    'secret': "secretkey",
    'name': 'sessionId',
    'unset': 'destroy',
    'resave': true,
    'saveUninitialized': true
}));

app.use(cookieParser("secretkey"));
app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(bodyParser.json({limit: '5mb'}));

//app.use(expressValidator());
app.use(expressValidator({
 customValidators: {
    notEquals: function(param, num) {
        return param != num;
    }
 }
}));

//app.set('appPath', path.join(__dirname));

app.use("/uploads/", express.static(__dirname + '/uploads/'));
//app.use(express.static(path.join(__dirname, '/dist')));

var adminrouter = require('./server/adminRoutes');
adminrouter(app);

var approuter = require('./server/appRoutes');
approuter(app);

app.get('/', function(req, res) {
    res.send('Hello!');
});

app.listen(port);
console.log('Server started.');