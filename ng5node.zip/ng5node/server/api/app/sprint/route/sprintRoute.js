'use strict';

var sprint = require('../controller/sprintController');

module.exports = function(app) {
    app.post('/app/api/sprint/add', sprint.addSprint);
    app.post('/app/api/sprint/delete', sprint.deleteSprint);
};