'use strict';

var db = require('../../../../config/sequelize').db;
var generalConfig = require('../../../../config/generalConfig');
var commonLib = require('../../../../lib/common');
var Sequelize = require("sequelize");

/**
 * post add sprint
 * @return json
 */

exports.addSprint = function(req, res, next) {
    
  //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
                    error:true,
                    data:null,
                    msg:'No access. Please login again'
                });
    }

    if (req.body != "") {
        req.checkBody('session_id', 'Invalid session details').notEmpty();
        req.checkBody('sprint_start_time', 'Sprint start time is required').notEmpty();
        req.checkBody('sprint_end_time', 'Sprint end time is required').notEmpty();

        var mappedErrors = req.validationErrors(true);
    }

    var failmsg = 'Error adding sprint.';
    var successmsg = 'Sprint added successfully.';

    if (mappedErrors == false) {

       var add_sprint = req.body;
       
        var sprintRequest = [];
        sprintRequest = {
            session_id: add_sprint.session_id,
            sprint_start_time: add_sprint.sprint_start_time,
            sprint_end_time: add_sprint.sprint_end_time,
            ST: (add_sprint.ST || add_sprint.ST == 0)?add_sprint.ST:null,
            RT: add_sprint.RT?add_sprint.RT:null,
            distance_30: add_sprint.distance_30?add_sprint.distance_30:null,
            distance_50: add_sprint.distance_50?add_sprint.distance_50:null,
            distance_100: add_sprint.distance_100?add_sprint.distance_100:null,
            status:1
        }

        db.models.sprint.create(sprintRequest).then(function(newSprint) {
            if(newSprint) {

                newSprint.setDataValue('coaching_tips', "");
                newSprint.setDataValue('highlight_lowest_time', []);

                var session_id = add_sprint.session_id;
                db.models.session.associate(db.models);

                // Get coaching tips
                db.models.session.find({
                    attributes: ['session_id', 'rider_id', 'session_start_date', 'session_end_date', 'max_distance', 'measurement_unit', 'workout_type'],

                    include: [{
                        model: db.models.sprint,
                        attributes: [
                            [Sequelize.fn('count', Sequelize.col('sprint_id')), 'total_sprint'],
                            [Sequelize.fn('IF', Sequelize.col('distance_100'), Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_100')), 3), Sequelize.fn('IF', Sequelize.col('distance_50'), Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_50')), 3), Sequelize.fn('IF', Sequelize.col('distance_30'), Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_30')), 3), ''))), 'final_avg'],
                            [Sequelize.fn('MIN', Sequelize.col('distance_30')), 'min_distance_30'],
                            [Sequelize.fn('MIN', Sequelize.col('distance_50')), 'min_distance_50'],
                            [Sequelize.fn('MIN', Sequelize.col('distance_100')), 'min_distance_100']
                        ],
                        where: { deletedAt: { $eq: null }, status: 1 },
                        duplicating: false
                    }],
                    where: {
                        session_id: session_id,
                        deletedAt: { $eq: null },
                        status: 1
                    },
                    group: 'session_id'
                }).then(function(findSession) {

                    if (findSession) {

                        // Sprint array to object
                        if (findSession.sprints.length > 0) {
                            findSession.setDataValue('sprints_detail', findSession.dataValues.sprints[0].dataValues);
                        } else {
                            findSession.setDataValue('sprints_detail', {});
                        }

                        delete findSession.dataValues.sprints;

                        var max_distance;
                        var workout_type;
                        var rider_id;
                        var currentSessionTotalSprint;
                        var currentSessionFinalAvg;
                        var currentSessionEndDate;
                        var previousSessionFinalAvg;

                        if (findSession.dataValues.sprints_detail !== undefined) {
                            currentSessionFinalAvg = findSession.dataValues.sprints_detail.final_avg;
                            currentSessionTotalSprint = findSession.dataValues.sprints_detail.total_sprint;
                            
                            // Highlight Lowest Time within session ( if sprint is more than 1 )
                            // append 1 to highlight_lowest_time if distance_30 is lowest within session
                            // append 2 to highlight_lowest_time if distance_50 is lowest within session
                            // append 3 to highlight_lowest_time if distance_100 is lowest within session
                            
                            if(currentSessionTotalSprint != 1){

                                if(findSession.dataValues.sprints_detail.min_distance_30 !== null && sprintRequest.distance_30 !== null){
                                    if(sprintRequest.distance_30 <= findSession.dataValues.sprints_detail.min_distance_30){
                                        newSprint.getDataValue('highlight_lowest_time').push(1);
                                    }
                                }

                                if(findSession.dataValues.sprints_detail.min_distance_50 !== null && sprintRequest.distance_50 !== null){
                                    if(sprintRequest.distance_50 <= findSession.dataValues.sprints_detail.min_distance_50){
                                        newSprint.getDataValue('highlight_lowest_time').push(2);
                                    }
                                }

                                if(findSession.dataValues.sprints_detail.min_distance_100 !== null && sprintRequest.distance_100 !== null){
                                    if(sprintRequest.distance_100 <= findSession.dataValues.sprints_detail.min_distance_100){
                                        newSprint.getDataValue('highlight_lowest_time').push(3);
                                    }
                                }

                            }

                        }

                        currentSessionEndDate = findSession.dataValues.session_end_date;

                        // Get coaching tips from (max_distance,rider_id,workout_type,session_id)
                        // Compare currentSessionFinalAvg with previousSessionFinalAvg

                        max_distance = findSession.dataValues.max_distance;
                        workout_type = findSession.dataValues.workout_type;
                        rider_id = findSession.dataValues.rider_id;

                        if (max_distance && rider_id && workout_type) {

                            db.models.session.find({

                                attributes: ['session_id'],

                                include: [{
                                    model: db.models.sprint,
                                    attributes: [
                                        [Sequelize.fn('COUNT', Sequelize.col('sprint_id')), 'total_sprints'],
                                        [Sequelize.fn('IF', Sequelize.col('distance_100'), Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_100')), 3), Sequelize.fn('IF', Sequelize.col('distance_50'), Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_50')), 3), Sequelize.fn('IF', Sequelize.col('distance_30'), Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_30')), 3), ''))), 'final_avg']
                                    ],
                                    where: { deletedAt: { $eq: null }, status: 1 },
                                    duplicating: false
                                }],

                                where: {
                                    session_id: { $lt: session_id },
                                    max_distance: max_distance,
                                    rider_id: rider_id,
                                    workout_type: workout_type,
                                    deletedAt: { $eq: null },
                                    status: 1
                                },

                                limit: 1,
                                order: [
                                    ['session_id', 'DESC']
                                ],
                                having:{ 
                                    'sprints.total_sprints': {
                                        $gt: 0
                                    }
                                },
                                group: 'session_id'

                            }).then(function(findPreviousSession) {

                                // Session details

                                if (findPreviousSession) {

                                    if (findPreviousSession.dataValues.sprints !== undefined && findPreviousSession.dataValues.sprints.length > 0) {
                                        previousSessionFinalAvg = findPreviousSession.dataValues.sprints[0].dataValues.final_avg;
                                    }

                                }

                                // Get coaching tips
                                if (workout_type && previousSessionFinalAvg && currentSessionFinalAvg && currentSessionTotalSprint) {
                                    // 1 :- Greater than 100% , 
                                    // 2 :- 100 - 98% , 
                                    // 3 :- 95 - 97.9% , 
                                    // 4 :- 94.9% or less
                                    // a= (nv-ov)*100/nv  FV= 100-a %
                                    // nv=new value , ov= Old value , fv= Final value 

                                    var sessionPercentage;
                                    var whereSessionAvg;

                                    sessionPercentage = 100 - ((currentSessionFinalAvg - previousSessionFinalAvg) * 100 / currentSessionFinalAvg);

                                    if (sessionPercentage > 100) {
                                        whereSessionAvg = 1;
                                    } else if (sessionPercentage <= 100 && sessionPercentage >= 98) {
                                        whereSessionAvg = 2;
                                    } else if (sessionPercentage < 98 && sessionPercentage >= 95) {
                                        whereSessionAvg = 3;
                                    } else {
                                        whereSessionAvg = 4;
                                    }

                                    // Get Coaching Criteria

                                    db.models.coaching_criteria.find({
                                        where: {
                                            workout_type_id: workout_type,
                                            session_avg: whereSessionAvg,
                                            deletedAt: { $eq: null }
                                        }
                                    }).then(function(coaching_criteria) {

                                        if (coaching_criteria) {

                                            // If session completed use post_workout_msg column else use sprint_1_to_6_msg or sprint_7_or_more_msg column

                                            if(currentSessionEndDate){
                                                
                                                newSprint.setDataValue('coaching_tips', coaching_criteria.dataValues.post_workout_msg);

                                                commonLib.output(res,{
                                                    error:false,
                                                    data:newSprint,
                                                    message:successmsg
                                                });

                                            } else {

                                                if(currentSessionTotalSprint <= 6){
                                                    newSprint.setDataValue('coaching_tips', coaching_criteria.dataValues.sprint_1_to_6_msg);

                                                    commonLib.output(res,{
                                                        error:false,
                                                        data:newSprint,
                                                        message:successmsg
                                                    });

                                                } else {
                                                    newSprint.setDataValue('coaching_tips', coaching_criteria.dataValues.sprint_7_or_more_msg);

                                                    commonLib.output(res,{
                                                        error:false,
                                                        data:newSprint,
                                                        message:successmsg
                                                    });
                                                    
                                                }

                                            }
                                            
                                        } else {
                                            
                                            commonLib.output(res,{
                                                error:false,
                                                data:newSprint,
                                                message:successmsg
                                            });

                                        }

                                    }).catch(function(err) {
                                        // commonLib.output(res, {
                                        //     error: true,
                                        //     data: null,
                                        //     message: "Oops! Something went wrong."
                                        // });

                                        commonLib.output(res,{
                                            error:false,
                                            data:newSprint,
                                            message:successmsg
                                        });
                                    });

                                } else {
                                    commonLib.output(res,{
                                        error:false,
                                        data:newSprint,
                                        message:successmsg
                                    });
                                }


                            }).catch(function(err) {
                                // commonLib.output(res, {
                                //     error: true,
                                //     data: null,
                                //     message: "Oops! Something went wrong."+err
                                // });

                                commonLib.output(res,{
                                    error:false,
                                    data:newSprint,
                                    message:successmsg
                                });
                            });

                        } else {
                            commonLib.output(res,{
                                error:false,
                                data:newSprint,
                                message:successmsg
                            });
                        }

                    } else {
                        commonLib.output(res,{
                            error:false,
                            data:newSprint,
                            message:successmsg
                        });
                    }

                }).catch(function(err) {
                    // commonLib.output(res, {
                    //     error: true,
                    //     data: null,
                    //     message: "Oops! Something went wrong."+err
                    // });

                    commonLib.output(res,{
                        error:false,
                        data:newSprint,
                        message:successmsg
                    });
                });

            } else {
                commonLib.output(res,{
                    error:true,
                    data:null,
                    message:failmsg
                });
            }
        }).catch(function(err){
            commonLib.output(res,{
                error:true,
                data:null,
                message:"Oops! Something went wrong."
            });
        });

    } else {

        commonLib.output(res,{
            error: true,
            data: null,
            message: failmsg,
        });

    }
};

/**
 * post delete sprint
 * @return json
 */

exports.deleteSprint = function(req, res, next) {
    
  //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
                    error:true,
                    data:null,
                    msg:'No access. Please login again'
                });
    }

    if (req.body != "") {
        req.checkBody('sprint_id', 'Invalid sprint details').notEmpty();
        var mappedErrors = req.validationErrors(true);
    }

    var failmsg = 'Error deleting sprint.';
    var successmsg = 'Sprint deleted successfully.';

    if (mappedErrors == false) {

       db.models.sprint.find({
            where: {
                sprint_id: req.body.sprint_id,
                deletedAt: { $eq: null }
            }
        }).then(function(findSprint) {

            if (findSprint) {
                
                var sprintRequest = [];
                    sprintRequest = {
                        deletedAt:new Date()
                    }

                db.models.sprint.update(sprintRequest, {
                            where: { sprint_id: req.body.sprint_id }
                        }).then(function(deleteSprint) {

                            if (deleteSprint) {
                                commonLib.output(res,{
                                    error: false,
                                    data: {sprint_id:req.body.sprint_id},
                                    message: successmsg
                                });
                            } else {
                                commonLib.output(res,{
                                    error: true,
                                    data: null,
                                    message: failmsg
                                });
                            }
                        }).catch(function(err) {
                            commonLib.output(res,{
                                error: true,
                                data: null,
                                message: "Oops! Something went wrong."
                            });
                        });

            } else {
                commonLib.output(res,{
                    error: true,
                    data: null,
                    message: 'No Sprint Found.'
                });
            } 

        }).catch(function(err) {
            commonLib.output(res,{
                error: true,
                data: null,
                message: "Oops! Something went wrong."
            });
        });

    } else {

        commonLib.output(res,{
            error: true,
            data: null,
            message: failmsg,
        });

    }
};
