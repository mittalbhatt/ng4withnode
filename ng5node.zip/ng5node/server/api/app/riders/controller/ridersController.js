'use strict';

var db = require('../../../../config/sequelize').db;
var generalConfig = require('../../../../config/generalConfig');
var commonLib = require('../../../../lib/common');
var thumb = require('node-thumbnail').thumb;
var Sequelize = require("sequelize");
var base64Img = require('base64-img');
const fs = require('fs');
var _ = require('lodash');

/**
 * Add rider
 * @return json
 */
exports.addRider = function(req, res, next) {

    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    if (req.body != "") {
        req.checkBody('trainer_id', 'Invalid trainer details').notEmpty();
        req.checkBody('first_name', 'First Name is required').notEmpty();
        req.checkBody('last_name', 'Last Name is required').notEmpty();
        req.checkBody('email', 'Email is required').notEmpty();
        var mappedErrors = req.validationErrors(true);
    }

    var failmsg = 'Error adding rider.';
    var successmsg = 'Rider added successfully.';

    if (mappedErrors == false) {

        var addrider = req.body;

        if (addrider.profile_image) {

            if (!addrider.image_type) {
                addrider.image_type = 'jpg';
            }

            var profile_image_name = Math.floor(Math.random() * 89999 + 10000) + Date.now();
        } else {
            var profile_image_name = '';
        }

        var riderRequest = [];
        riderRequest = {
            trainer_id: addrider.trainer_id,
            firstname: addrider.first_name,
            lastname: addrider.last_name,
            email: addrider.email,
            profile_image: addrider.profile_image ? profile_image_name + '.' + addrider.image_type : '',
            mobile_no: addrider.mobile_no ? addrider.mobile_no : null,
            height: addrider.height ? addrider.height : null,
            weight: addrider.weight ? addrider.weight : null,
            age: addrider.age ? addrider.age : null,
            active: 1
        }

        db.models.rider.findAll({
            where: {
                email: addrider.email,
                trainer_id: addrider.trainer_id,
                deletedAt: { $eq: null }
            }
        }).then(function(found_rider) {

            if (found_rider.length == 0) {

                db.models.rider.create(riderRequest).then(function(newRider) {
                    if (newRider) {

                        // Upload image

                        if (addrider.profile_image) {
                            base64Img.img('data:image/' + addrider.image_type + ';base64,' + addrider.profile_image, generalConfig.filesPath.riders_profilepicture, profile_image_name, function(err, filepath) {});
                        }

                        // For full image path
                        var newRiderOutput = [];
                        newRiderOutput[0] = newRider;

                        commonLib.getRiderImage(newRiderOutput, function() {
                            commonLib.output(res, {
                                error: false,
                                data: newRiderOutput[0],
                                message: "Rider added successfully."
                            });
                        });


                    } else {
                        commonLib.output(res, {
                            error: true,
                            data: null,
                            message: "Error adding rider."
                        });
                    }
                }).catch(function(err) {
                    commonLib.output(res, {
                        error: true,
                        data: null,
                        message: "Oops! Something went wrong."
                    });
                });

            } else {
                commonLib.output(res, {
                    error: true,
                    data: null,
                    message: "Rider already registered."
                });
            }

        }).catch(function(err) {
            commonLib.output(res, {
                error: true,
                data: null,
                message: "Oops! Something went wrong."
            });
        });

    } else {

        var mappedErrors_msg = mappedErrors[Object.keys(mappedErrors)[0]].msg;
        mappedErrors_msg = mappedErrors_msg ? mappedErrors_msg : failmsg;

        commonLib.output(res, {
            error: true,
            data: null,
            message: mappedErrors_msg,
        });

    }
};

/**
 * Edit rider
 * @return json
 */
exports.editRider = function(req, res, next) {

    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    if (req.body != "") {
        req.checkBody('rider_id', 'Invalid rider details').notEmpty();
        req.checkBody('trainer_id', 'Invalid trainer details').notEmpty();
        req.checkBody('first_name', 'First Name is required').notEmpty();
        req.checkBody('last_name', 'Last Name is required').notEmpty();
        req.checkBody('email', 'Email is required').notEmpty();
        var mappedErrors = req.validationErrors(true);
    }

    var failmsg = 'Error updating rider.';
    var successmsg = 'Rider updated successfully.';

    if (mappedErrors == false) {

        var editrider = req.body;

        var riderRequest = [];
        riderRequest = {
            firstname: editrider.first_name,
            lastname: editrider.last_name,
            email: editrider.email
        }

        if (typeof editrider.mobile_no !== 'undefined') {
            if (!editrider.mobile_no) editrider.mobile_no = null;
            riderRequest['mobile_no'] = editrider.mobile_no;
        }

        if (typeof editrider.height !== 'undefined') {
            if (!editrider.height) editrider.height = null;
            riderRequest['height'] = editrider.height;
        }

        if (typeof editrider.weight !== 'undefined') {
            if (!editrider.weight) editrider.weight = null;
            riderRequest['weight'] = editrider.weight;
        }

        if (typeof editrider.age !== 'undefined') {
            if (!editrider.age) editrider.age = null;
            riderRequest['age'] = editrider.age;
        }

        if (typeof editrider.active !== 'undefined') {
            riderRequest['active'] = editrider.active;
        }

        if (editrider.profile_image) {

            if (!editrider.image_type) {
                editrider.image_type = 'jpg';
            }

            var profile_image_name = Math.floor(Math.random() * 89999 + 10000) + Date.now();
            riderRequest['profile_image'] = editrider.profile_image ? profile_image_name + '.' + editrider.image_type : '';

        }

        db.models.rider.findAll({
            where: {
                rider_id: editrider.rider_id,
                trainer_id: editrider.trainer_id,
                deletedAt: { $eq: null }
            }
        }).then(function(found_rider) {

            if (found_rider.length == 0) {

                commonLib.output(res, {
                    error: true,
                    data: null,
                    message: "Rider not found."
                });

            } else {

                // Check email already used or not
                db.models.rider.findAll({
                    where: {
                        rider_id: { $ne: editrider.rider_id },
                        trainer_id: editrider.trainer_id,
                        email: editrider.email,
                        deletedAt: { $eq: null }
                    }
                }).then(function(is_duplicate_email) {

                    if (is_duplicate_email.length == 0) {

                        db.models.rider.update(riderRequest, {
                            where: { rider_id: editrider.rider_id }
                        }).then(function(edit_rider) {

                            if (edit_rider) {

                                //Upload image
                                try {
                                    if (editrider.profile_image && editrider.profile_image != '') {
                                        base64Img.img('data:image/' + editrider.image_type + ';base64,' + editrider.profile_image, generalConfig.filesPath.riders_profilepicture, profile_image_name, function(err, filepath) {});
                                    }
                                } catch (err) { console.log(err); }

                                //Delete old image 
                                try {
                                    if (found_rider[0].profile_image && editrider.profile_image && editrider.profile_image != '') {

                                        var imagePath = generalConfig.filesPath.riders_profilepicture + found_rider[0].profile_image;

                                        if (fs.existsSync(imagePath)) {
                                            fs.unlink(imagePath, function(err) {
                                                if (err) { console.log(err); }
                                            });
                                        }
                                    }
                                } catch (err) { console.log(err); }

                                // Get updated data
                                db.models.rider.findAll({
                                    attributes: ['rider_id', 'trainer_id', 'firstname', 'lastname', 'email', 'profile_image', 'mobile_no', 'height', 'weight', 'age', 'active'],
                                    where: {
                                        rider_id: editrider.rider_id,
                                        deletedAt: { $eq: null }
                                    }
                                }).then(function(updatedRider) {

                                    commonLib.getRiderImage(updatedRider, function() {
                                        commonLib.output(res, {
                                            error: false,
                                            data: updatedRider[0],
                                            message: "Rider updated successfully."
                                        });
                                    });

                                }).catch(function(err) {
                                    commonLib.output(res, {
                                        error: false,
                                        data: null,
                                        message: "Rider updated successfully."
                                    });
                                });


                            } else {
                                commonLib.output(res, {
                                    error: true,
                                    data: null,
                                    message: "Error updating rider."
                                });
                            }

                        }).catch(function(err) {
                            commonLib.output(res, {
                                error: true,
                                data: null,
                                message: "Oops! Something went wrong."
                            });
                        });

                    } else {

                        commonLib.output(res, {
                            error: true,
                            data: null,
                            message: 'Email already in used.',
                        });

                    }

                }).catch(function(err) {
                    console.log(err);
                    commonLib.output(res, {
                        error: true,
                        data: null,
                        message: "Oops! Something went wrong."
                    });
                });

            }

        }).catch(function(err) {
            console.log(err);
            commonLib.output(res, {
                error: true,
                data: null,
                message: "Oops! Something went wrong."
            });
        });

    } else {

        var mappedErrors_msg = mappedErrors[Object.keys(mappedErrors)[0]].msg;
        mappedErrors_msg = mappedErrors_msg ? mappedErrors_msg : failmsg;

        commonLib.output(res, {
            error: true,
            data: null,
            message: mappedErrors_msg,
        });

    }
};

/**
 * Delete rider
 * @return json
 */
exports.deleteRider = function(req, res, next) {

    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    if (req.body != "") {
        req.checkBody('rider_id', 'Invalid rider details').notEmpty();
        var mappedErrors = req.validationErrors(true);
    }

    var failmsg = 'Error deleting rider.';
    var successmsg = 'Rider deleted successfully.';

    if (mappedErrors == false) {

        db.models.rider.find({
            where: {
                rider_id: req.body.rider_id,
                deletedAt: { $eq: null }
            }
        }).then(function(findRider) {

            if (findRider) {

                var riderRequest = [];
                riderRequest = {
                    deletedAt: new Date(),
                    active: 0
                }

                db.models.rider.update(riderRequest, {
                    where: { rider_id: req.body.rider_id }
                }).then(function(deleteRider) {

                    if (deleteRider) {
                        commonLib.output(res, {
                            error: false,
                            data: { rider_id: req.body.rider_id },
                            message: successmsg
                        });
                    } else {
                        commonLib.output(res, {
                            error: true,
                            data: null,
                            message: failmsg
                        });
                    }
                }).catch(function(err) {
                    commonLib.output(res, {
                        error: true,
                        data: null,
                        message: "Oops! Something went wrong."
                    });
                });

            } else {
                commonLib.output(res, {
                    error: true,
                    data: null,
                    message: 'No Rider Found.'
                });
            }

        }).catch(function(err) {
            commonLib.output(res, {
                error: true,
                data: null,
                message: "Oops! Something went wrong."
            });
        });

    } else {

        commonLib.output(res, {
            error: true,
            data: null,
            message: failmsg,
        });

    }

};

/**
 * get all riders
 * @return json
 */

exports.getAllRiders = function(req, res, next) {

    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    db.models.rider.associate(db.models);

    db.models.rider
        .findAll({
            attributes: ['rider_id', 'trainer_id', 'firstname', 'lastname', 'email', 'profile_image', 'height', 'weight', 'age', 'mobile_no', 'active'],
            where: {
                deletedAt: { $eq: null },
                active: 1
            },
            include: [{
                model: db.models.user,
                as: 'trainer_details',
                attributes: ['firstname', 'lastname', 'mobile_no', 'email', 'profile_image']
            }]
        })
        .then(function(riders) {
            if (riders) {
                commonLib.getRiderImage(riders, function() {
                    commonLib.output(res, {
                        error: false,
                        data: riders,
                        message: "Riders found"
                    });
                });

            } else {
                commonLib.output(res, {
                    error: false,
                    data: null,
                    message: "No riders found"
                });
            }
        })
        .catch(function(err) {
            commonLib.output(res, {
                error: true,
                data: null,
                message: "Oops! Something went wrong."
            });
        });

};

/**
 * get riders from trainer
 * @return json
 */

exports.getRidersFromTrainer = function(req, res, next) {

    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    if (req.body != "") {
        req.checkBody('trainer_id', 'Invalid trainer details').notEmpty();
        var mappedErrors = req.validationErrors(true);
    }

    if (mappedErrors == false) {
        db.models.rider.associate(db.models);

        db.models.rider
            .findAll({
                attributes: ['rider_id', 'trainer_id', 'firstname', 'lastname', 'email', 'profile_image', 'height', 'weight', 'age', 'mobile_no', 'active'],
                where: {
                    deletedAt: { $eq: null },
                    trainer_id: req.body.trainer_id,
                    active: 1
                },
                include: [{
                    model: db.models.session,
                    attributes: [
                        [Sequelize.fn('count', Sequelize.col('session_id')), 'total_session']
                    ],
                    duplicating: false
                }],
                group: 'rider_id'
            })
            .then(function(riders) {

                if (riders) {

                    if (riders.length > 0) {
                        commonLib.getRiderImage(riders, function() {

                            _.forEach(riders, function(value, key) {
                                if (value.sessions.length > 0) {
                                    value.setDataValue('total_sessions', value.sessions[0].dataValues.total_session);
                                } else {
                                    value.setDataValue('total_sessions', 0);
                                }

                                delete value.dataValues.sessions;
                            });

                            commonLib.output(res, {
                                error: false,
                                data: riders,
                                message: "Riders found"
                            });
                        });
                    } else {
                        commonLib.output(res, {
                            error: false,
                            data: null,
                            message: "No riders found"
                        });
                    }

                } else {
                    commonLib.output(res, {
                        error: false,
                        data: null,
                        message: "No riders found"
                    });
                }
            })
            .catch(function(err) {
                commonLib.output(res, {
                    error: true,
                    data: null,
                    message: "Oops! Something went wrong." + err
                });
            });
    } else {
        commonLib.output(res, {
            error: true,
            data: null,
            message: 'Invalid trainer details',
        });
    }

};

/**
 * get rider profile
 * @return json
 */

exports.getRiderSessionDetails = function(req, res, next) {

    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    if (req.body != "") {
        req.checkBody('rider_id', 'Invalid rider details').notEmpty();
        req.checkBody('trainer_id', 'Invalid trainer details').notEmpty();
        var mappedErrors = req.validationErrors(true);
    }

    if (typeof req.body.measurement_unit === 'undefined') {
        req.body.measurement_unit = 'feet';
    }

    if (mappedErrors == false) {
        db.models.session.associate(db.models);

        /* //----QUERY----
        SELECT `session`.`session_id`,
         `session`.`session_start_date`,
         `session`.`session_end_date`,
         `session`.`max_distance`,
         `session`.`measurement_unit`,
         `sprints`.`sprint_id` AS `sprints.sprint_id`,
         count(`sprint_id`) AS `sprints.total_sprint`,
         ROUND(avg(`ST`),3) AS `sprints.avg_st`,
         ROUND(avg(`RT`),3) AS `sprints.avg_rt`,
         ROUND(avg(`distance_30`),3) AS `sprints.avg_30`,
         ROUND(avg(`distance_50`),3) AS `sprints.avg_50`,
         ROUND(avg(`distance_100`),3) AS `sprints.avg_100`,
         IF(`distance_100`,ROUND(avg(`distance_100`),3),IF(`distance_50`,ROUND(avg(`distance_50`),3),IF(`distance_30`,ROUND(avg(`distance_30`),3),''))) AS `sprints.final_avg`
        FROM `bmx_sessions` AS `session` LEFT OUTER
        JOIN `bmx_sprints` AS `sprints`
            ON `session`.`session_id` = `sprints`.`session_id`
        WHERE `session`.`deletedAt` IS NULL
                AND `session`.`status` = 1
                AND `session`.`trainer_id` = 2
                AND `session`.`rider_id` = 2
                AND `session`.`workout_type` = 2
                AND `session`.`measurement_unit` = 'feet'
        GROUP BY  session_id;
        */

        //Get rider details
        db.models.rider
            .findAll({
                attributes: ['rider_id', 'trainer_id', 'firstname', 'lastname', 'email', 'profile_image', 'height', 'weight', 'age', 'active'],
                where: {
                    rider_id: req.body.rider_id,
                    trainer_id: req.body.trainer_id,
                    deletedAt: { $eq: null }
                }
            })
            .then(function(rider) {

                if (rider.length > 0) {

                    commonLib.getRiderImage(rider, function() {

                        if (req.body.workout_type && req.body.workout_type != '') {
                            var whereRiderPreviousSession = {
                                deletedAt: { $eq: null },
                                session_end_date: { $ne: null },
                                status: 1,
                                trainer_id: req.body.trainer_id,
                                rider_id: req.body.rider_id,
                                workout_type: req.body.workout_type,
                                measurement_unit: req.body.measurement_unit
                            }

                        } else {

                            var whereRiderPreviousSession = {
                                deletedAt: { $eq: null },
                                session_end_date: { $ne: null },
                                status: 1,
                                trainer_id: req.body.trainer_id,
                                rider_id: req.body.rider_id,
                                measurement_unit: req.body.measurement_unit
                            }
                        }

                        //If rider found - get previous session details of rider
                        db.models.session
                            .findAll({
                                attributes: ['session_id', 'session_start_date','session_end_date', 'max_distance', 'measurement_unit', 'workout_type'],

                                include: [{
                                    model: db.models.sprint,
                                    attributes: [
                                        [Sequelize.fn('count', Sequelize.col('sprint_id')), 'total_sprint'],
                                        [Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('ST')), 3), 'avg_st'],
                                        [Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('RT')), 3), 'avg_rt'],
                                        [Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_30')), 3), 'avg_30'],
                                        [Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_50')), 3), 'avg_50'],
                                        [Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_100')), 3), 'avg_100'],
                                        [Sequelize.fn('IF', Sequelize.col('distance_100'), Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_100')), 3), Sequelize.fn('IF', Sequelize.col('distance_50'), Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_50')), 3), Sequelize.fn('IF', Sequelize.col('distance_30'), Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_30')), 3), ''))), 'final_avg']
                                    ],
                                    where: { deletedAt: { $eq: null }, status: 1 },
                                    duplicating: false,
                                    required: false
                                }],

                                where: whereRiderPreviousSession,
                                order: [
                                    ['session_id', 'DESC']
                                ],
                                having:{ 
                                    'sprints.total_sprint': {
                                        $gt: 0
                                    }
                                },
                                offset: 0,
                                limit: 10,
                                group: 'session_id'
                            })
                            .then(function(riderPreviousSession) {

                                // Sprint array to object
                                _.forEach(riderPreviousSession, function(value, key) {

                                    if (value.sprints.length > 0) {
                                        riderPreviousSession[key].setDataValue('sprints_detail', riderPreviousSession[key].dataValues.sprints[0].dataValues);
                                    } else {
                                        riderPreviousSession[key].setDataValue('sprints_detail', {});
                                    }

                                    delete riderPreviousSession[key].dataValues.sprints;

                                });

                                // if(req.body.workout_type && req.body.workout_type != ''){
                                //     var whereRiderCurrentSession = {
                                //             deletedAt: { $eq: null },
                                //             session_end_date: { $eq: null },
                                //             status: 1,
                                //             trainer_id: req.body.trainer_id,
                                //             rider_id: req.body.rider_id,
                                //             workout_type: req.body.workout_type,
                                //             measurement_unit: req.body.measurement_unit
                                //         }

                                // } else {

                                //     var whereRiderCurrentSession = {
                                //             deletedAt: { $eq: null },
                                //             session_end_date: { $eq: null },
                                //             status: 1,
                                //             trainer_id: req.body.trainer_id,
                                //             rider_id: req.body.rider_id,
                                //             measurement_unit: req.body.measurement_unit
                                //         }
                                // }

                                // Current session not dependent on workout

                                var whereRiderCurrentSession = {
                                    deletedAt: { $eq: null },
                                    session_end_date: { $eq: null },
                                    status: 1,
                                    trainer_id: req.body.trainer_id,
                                    rider_id: req.body.rider_id,
                                    measurement_unit: req.body.measurement_unit
                                }

                                //get current session details of rider
                                db.models.session
                                    .findAll({
                                        attributes: ['session_id', 'session_start_date','session_end_date', 'max_distance', 'measurement_unit', 'workout_type'],

                                        include: [{
                                            model: db.models.sprint,
                                            attributes: [
                                                [Sequelize.fn('count', Sequelize.col('sprint_id')), 'total_sprint'],
                                                [Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('ST')), 3), 'avg_st'],
                                                [Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('RT')), 3), 'avg_rt'],
                                                [Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_30')), 3), 'avg_30'],
                                                [Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_50')), 3), 'avg_50'],
                                                [Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_100')), 3), 'avg_100'],
                                                [Sequelize.fn('IF', Sequelize.col('distance_100'), Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_100')), 3), Sequelize.fn('IF', Sequelize.col('distance_50'), Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_50')), 3), Sequelize.fn('IF', Sequelize.col('distance_30'), Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_30')), 3), ''))), 'final_avg']
                                            ],
                                            where: { deletedAt: { $eq: null }, status: 1 },
                                            duplicating: false,
                                            required: false
                                        }],

                                        where: whereRiderCurrentSession,
                                        group: 'session_id',
                                        order: [
                                            ['session_id', 'DESC']
                                        ]
                                    })
                                    .then(function(riderCurrentSession) {

                                        if (riderCurrentSession.length > 0) {

                                            riderCurrentSession = riderCurrentSession[0];

                                            // Sprint array to object
                                            if (riderCurrentSession.sprints.length > 0) {
                                                riderCurrentSession.setDataValue('sprints_detail', riderCurrentSession.sprints[0].dataValues);
                                            } else {
                                                riderCurrentSession.setDataValue('sprints_detail', {});
                                            }

                                            delete riderCurrentSession.dataValues.sprints;

                                        } else {
                                            riderCurrentSession = null;
                                        }

                                        if (rider[0] !== undefined) {
                                            rider = rider[0];
                                        }

                                        //Return rider profile and previous session details
                                        commonLib.output(res, {
                                            error: false,
                                            data: { profile: rider, previous_session: riderPreviousSession, current_session: riderCurrentSession },
                                            message: "Rider Details."
                                        });
                                    })
                                    .catch(function(err) {
                                        commonLib.output(res, {
                                            error: true,
                                            data: null,
                                            message: "Oops! Something went wrong."
                                        });
                                    });

                            })
                            .catch(function(err) {
                                commonLib.output(res, {
                                    error: true,
                                    data: null,
                                    message: "Oops! Something went wrong."
                                });
                            });

                    });
                } else {
                    commonLib.output(res, {
                        error: false,
                        data: null,
                        message: "No rider found"
                    });
                }

            })
            .catch(function(err) {
                commonLib.output(res, {
                    error: true,
                    data: null,
                    message: "Oops! Something went wrong."
                });
            });

    } else {

        var mappedErrors_msg = mappedErrors[Object.keys(mappedErrors)[0]].msg;
        mappedErrors_msg = mappedErrors_msg ? mappedErrors_msg : failmsg;

        commonLib.output(res, {
            error: true,
            data: null,
            message: mappedErrors_msg,
        });
    }

};
