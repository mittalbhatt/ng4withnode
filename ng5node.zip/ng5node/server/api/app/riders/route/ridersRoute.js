'use strict';

var rider = require('../controller/ridersController');
var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();

module.exports = function(app) {
    app.post('/app/api/rider/', rider.getRidersFromTrainer);
    app.get('/app/api/rider/all', rider.getAllRiders);
    app.post('/app/api/rider/add', multipartMiddleware, rider.addRider);
    app.post('/app/api/rider/edit', multipartMiddleware, rider.editRider);
    app.post('/app/api/rider/delete', rider.deleteRider);
    app.post('/app/api/rider/sessiondetails', rider.getRiderSessionDetails);
    // app.get('/app/api/rider/:id', rider.getRider);
};