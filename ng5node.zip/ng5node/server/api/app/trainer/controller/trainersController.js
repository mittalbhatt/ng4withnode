'use strict';

var db = require('../../../../config/sequelize').db;
var generalConfig = require('../../../../config/generalConfig');
var commonLib = require('../../../../lib/common');
var thumb = require('node-thumbnail').thumb;
var Sequelize = require("sequelize");
var base64Img = require('base64-img');
const fs = require('fs');

/**
 * Edit Trainer
 * @return json
 */
exports.editTrainer = function(req, res, next) {

    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    if (req.body != "") {
        req.checkBody('trainer_id', 'Invalid trainer details').notEmpty();
        req.checkBody('email', 'Email is required').notEmpty();
        req.checkBody('userdetails.first_name', 'First Name is required').notEmpty();
        req.checkBody('userdetails.last_name', 'Last Name is required').notEmpty();
        var mappedErrors = req.validationErrors(true);
    }

    var failmsg = 'Error updating trainer.';
    var successmsg = 'Profile updated successfully.';

    if (mappedErrors == false) {

        var edittrainer = req.body;

        var trainerRequest = [];
        trainerRequest = {
            firstname: edittrainer.userdetails.first_name,
            lastname: edittrainer.userdetails.last_name,
            email: edittrainer.email
        }

        if (typeof edittrainer.userdetails.mobile_no !== 'undefined') {
            if (!edittrainer.userdetails.mobile_no) edittrainer.userdetails.mobile_no = null;
            trainerRequest['mobile_no'] = edittrainer.userdetails.mobile_no;
        }

        if (typeof edittrainer.userdetails.active !== 'undefined') {
            trainerRequest['active'] = edittrainer.userdetails.active;
        }

        if (edittrainer.userdetails.image) {

            if (!edittrainer.userdetails.image_type) {
                edittrainer.userdetails.image_type = 'jpg';
            }

            var profile_image_name = Math.floor(Math.random() * 89999 + 10000) + Date.now();
            trainerRequest['profile_image'] = edittrainer.userdetails.image ? profile_image_name + '.' + edittrainer.userdetails.image_type : '';

        }

        db.models.user.findAll({
            where: {
                id: edittrainer.trainer_id,
                deletedAt: { $eq: null }
            }
        }).then(function(found_trainer) {

            if (found_trainer.length == 0) {

                commonLib.output(res, {
                    error: true,
                    data: null,
                    message: "Trainer not found."
                });

            } else {

                // Check email already used or not
                db.models.user.findAll({
                    where: {
                        id: { $ne: edittrainer.trainer_id },
                        email: edittrainer.email,
                        deletedAt: { $eq: null }
                    }
                }).then(function(is_duplicate_email) {

                    if (is_duplicate_email.length == 0) {

                        db.models.user.update(trainerRequest, {
                            where: { id: edittrainer.trainer_id }
                        }).then(function(edit_trainer) {

                            if (edit_trainer) {

                                //Upload image
                                try {
                                    if (edittrainer.userdetails.image && edittrainer.userdetails.image != '') {
                                        base64Img.img('data:image/' + edittrainer.userdetails.image_type + ';base64,' + edittrainer.userdetails.image, generalConfig.filesPath.userPicture, profile_image_name, function(err, filepath) {});
                                    }
                                } catch (err) { console.log(err); }

                                //Delete old image 
                                try {
                                    if (found_trainer[0].profile_image && edittrainer.userdetails.image && edittrainer.userdetails.image != '') {

                                        var imagePath = generalConfig.filesPath.userPicture + found_trainer[0].profile_image;

                                        if(fs.existsSync(imagePath)){
                                            fs.unlink(imagePath, function (err) {
                                                if (err) { console.log(err); }
                                            });
                                        }
                                    }
                                } catch (err) { console.log(err); }

                                // Get updated data
                                db.models.user.findAll({
                                    attributes: ['id', 'email', 'firstname', 'lastname', 'profile_image', 'mobile_no', 'active', 'is_fb_user', 'fb_id'],
                                    where: {
                                        id: edittrainer.trainer_id,
                                        deletedAt: { $eq: null }
                                    }
                                }).then(function(updatedTrainer) {

                                    commonLib.getTrainerImage(updatedTrainer, function() {
                                        commonLib.output(res, {
                                            error: false,
                                            data: updatedTrainer[0],
                                            message: "Profile updated successfully."
                                        });
                                    });

                                }).catch(function(err) {
                                    commonLib.output(res, {
                                        error: false,
                                        data: null,
                                        message: "Profile updated successfully."
                                    });
                                });

                            } else {
                                commonLib.output(res, {
                                    error: true,
                                    data: null,
                                    message: "Error updating trainer."
                                });
                            }

                        }).catch(function(err) {
                            commonLib.output(res, {
                                error: true,
                                data: null,
                                message: "Oops! Something went wrong."
                            });
                        });

                    } else {

                        commonLib.output(res, {
                            error: true,
                            data: null,
                            message: 'Email already in used.',
                        });

                    }

                }).catch(function(err) {
                    console.log(err);
                    commonLib.output(res, {
                        error: true,
                        data: null,
                        message: "Oops! Something went wrong."
                    });
                });

            }

        }).catch(function(err) {
            console.log(err);
            commonLib.output(res, {
                error: true,
                data: null,
                message: "Oops! Something went wrong."
            });
        });

    } else {

        var mappedErrors_msg = mappedErrors[Object.keys(mappedErrors)[0]].msg;
        mappedErrors_msg = mappedErrors_msg ? mappedErrors_msg : failmsg;

        commonLib.output(res, {
            error: true,
            data: null,
            message: mappedErrors_msg,
        });

    }
};

/**
 * Delete Trainer
 * @return json
 */
exports.deleteTrainer = function(req, res, next) {

    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    if (req.body != "") {
        req.checkBody('trainer_id', 'Invalid trainer details').notEmpty();
        var mappedErrors = req.validationErrors(true);
    }

    var failmsg = 'Error deleting trainer.';
    var successmsg = 'Trainer deleted successfully.';

    if (mappedErrors == false) {

        db.models.user.find({
            where: {
                id: req.body.trainer_id,
                deletedAt: { $eq: null },
                is_admin: 0
            }
        }).then(function(findTrainer) {

            if (findTrainer) {

                var trainerRequest = [];
                trainerRequest = {
                    deletedAt: new Date(),
                    active: 0
                }

                db.models.user.update(trainerRequest, {
                    where: { id: req.body.trainer_id, is_admin: 0 }
                }).then(function(deleteTrainer) {

                    if (deleteTrainer) {
                        commonLib.output(res, {
                            error: false,
                            data: { trainer_id: req.body.trainer_id },
                            message: successmsg
                        });
                    } else {
                        commonLib.output(res, {
                            error: true,
                            data: null,
                            message: failmsg
                        });
                    }
                }).catch(function(err) {
                    commonLib.output(res, {
                        error: true,
                        data: null,
                        message: "Oops! Something went wrong."
                    });
                });

            } else {
                commonLib.output(res, {
                    error: true,
                    data: null,
                    message: 'No Trainer Found.'
                });
            }

        }).catch(function(err) {
            commonLib.output(res, {
                error: true,
                data: null,
                message: "Oops! Something went wrong."
            });
        });

    } else {

        var mappedErrors_msg = mappedErrors[Object.keys(mappedErrors)[0]].msg;
        mappedErrors_msg = mappedErrors_msg ? mappedErrors_msg : failmsg;

        commonLib.output(res, {
            error: true,
            data: null,
            message: mappedErrors_msg,
        });

    }

};

/**
 * Edit Trainer Password
 * @return json
 */

exports.editTrainerPassword = function(req, res, next) {

    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    if (req.body != "") {
        req.checkBody('trainer_id', 'Invalid trainer details.').notEmpty();
        req.checkBody('oldpassword', 'Old password is required.').notEmpty();
        req.checkBody('password', 'Password is required.').notEmpty();
        var mappedErrors = req.validationErrors(true);
    }

    var failmsg = 'Error updating password.';
    var successmsg = 'Password updated successfully.';

    if (mappedErrors == false) {

        db.models.user.find({
            where: {
                id: req.body.trainer_id,
                deletedAt: { $eq: null },
                is_admin: 0
            }
        }).then(function(findTrainer) {

            if (findTrainer) {
                
                if(findTrainer.password == generalConfig.encryptPassword(req.body.oldpassword)){
                    
                    var trainerRequest = [];
                    trainerRequest = {
                        password: generalConfig.encryptPassword(req.body.password)
                    }

                    db.models.user.update(trainerRequest, {
                        where: { id: req.body.trainer_id, is_admin: 0 }
                    }).then(function(passwordUpdate) {

                        if (passwordUpdate) {
                            commonLib.output(res, {
                                error: false,
                                data: { trainer_id: req.body.trainer_id },
                                message: successmsg
                            });
                        } else {
                            commonLib.output(res, {
                                error: true,
                                data: null,
                                message: failmsg
                            });
                        }
                    }).catch(function(err) {
                        commonLib.output(res, {
                            error: true,
                            data: null,
                            message: "Oops! Something went wrong."
                        });
                    });

                } else {
                    commonLib.output(res, {
                        error: true,
                        data: null,
                        message: "Oops! The password you have entered does not match your current one."
                    });
                }

            } else {
                commonLib.output(res, {
                    error: true,
                    data: null,
                    message: 'No Trainer Found.'
                });
            }

        }).catch(function(err) {
            commonLib.output(res, {
                error: true,
                data: null,
                message: "Oops! Something went wrong."
            });
        });

    } else {

        var mappedErrors_msg = mappedErrors[Object.keys(mappedErrors)[0]].msg;
        mappedErrors_msg = mappedErrors_msg ? mappedErrors_msg : failmsg;

        commonLib.output(res, {
            error: true,
            data: null,
            message: mappedErrors_msg,
        });

    }

};
