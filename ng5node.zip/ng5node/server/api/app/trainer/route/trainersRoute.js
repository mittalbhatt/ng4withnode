'use strict';

var trainer = require('../controller/trainersController');
var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();

module.exports = function(app) {
    app.post('/app/api/trainer/edit', multipartMiddleware, trainer.editTrainer);
    app.post('/app/api/trainer/editpassword', trainer.editTrainerPassword);
    app.post('/app/api/trainer/delete', trainer.deleteTrainer);
};