'use strict';

var db = require('../../../../config/sequelize').db;
var generalConfig = require('../../../../config/generalConfig');
var commonLib = require('../../../../lib/common');
var Sequelize = require("sequelize");
var _ = require('lodash');

/**
 * post start session
 * @return json
 */

exports.startSession = function(req, res, next) {

    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    if (req.body != "") {
        req.checkBody('session_start_date', 'Invalid trainer details').notEmpty();
        req.checkBody('workout_type', 'First Name is required').notEmpty();
        req.checkBody('max_distance', 'Max Distance is required').notEmpty();
        req.checkBody('trainer_id', 'Trainer is required').notEmpty();
        req.checkBody('rider_id', 'Rider is required').notEmpty();
        var mappedErrors = req.validationErrors(true);
    }

    var failmsg = 'Error starting session.';
    var successmsg = 'Session started successfully.';

    if (mappedErrors == false) {

        var start_session = req.body;

        var sessionRequest = [];
        sessionRequest = {
            session_start_date: start_session.session_start_date,
            workout_type: start_session.workout_type,
            max_distance: start_session.max_distance,
            trainer_id: start_session.trainer_id,
            rider_id: start_session.rider_id,
            measurement_unit: start_session.measurement_unit ? start_session.measurement_unit : 'feet',
            status: 1
        }

        db.models.session.create(sessionRequest).then(function(newSession) {
            if (newSession) {

                commonLib.output(res, {
                    error: false,
                    data: newSession,
                    message: successmsg
                });

            } else {
                commonLib.output(res, {
                    error: true,
                    data: null,
                    message: failmsg
                });
            }
        }).catch(function(err) {
            commonLib.output(res, {
                error: true,
                data: null,
                message: "Oops! Something went wrong."
            });
        });

    } else {

        commonLib.output(res, {
            error: true,
            data: null,
            message: failmsg,
        });

    }
};

/**
 * post end session
 * @return json
 */

exports.endSession = function(req, res, next) {

    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    if (req.body != "") {
        req.checkBody('session_id', 'Invalid session id').notEmpty();
        req.checkBody('session_end_date', 'Session end date is required').notEmpty();
        var mappedErrors = req.validationErrors(true);
    }

    var failmsg = 'Error ending session.';
    var successmsg = 'Session ended successfully.';

    if (mappedErrors == false) {

        var end_session = req.body;

        db.models.session.find({
            where: {
                session_id: end_session.session_id,
                session_end_date: { $eq: null },
                deletedAt: { $eq: null },
                status: 1
            }
        }).then(function(findSession) {

            if (findSession) {

                var sessionRequest = [];
                sessionRequest = {
                    session_end_date: end_session.session_end_date
                }

                db.models.session.update(sessionRequest, {
                    where: { session_id: end_session.session_id }
                }).then(function(endSession) {

                    if (endSession) {
                        commonLib.output(res, {
                            error: false,
                            data: { session_id: end_session.session_id },
                            message: successmsg
                        });
                    } else {
                        commonLib.output(res, {
                            error: true,
                            data: null,
                            message: failmsg
                        });
                    }
                }).catch(function(err) {
                    commonLib.output(res, {
                        error: true,
                        data: null,
                        message: "Oops! Something went wrong."
                    });
                });

            } else {
                commonLib.output(res, {
                    error: true,
                    data: null,
                    message: 'No Active Session Found.'
                });
            }

        }).catch(function(err) {
            commonLib.output(res, {
                error: true,
                data: null,
                message: "Oops! Something went wrong."
            });
        });

    } else {

        commonLib.output(res, {
            error: true,
            data: null,
            message: failmsg,
        });

    }
};

/**
 * post end session
 * @return json
 */

exports.sessionDetails = function(req, res, next) {

    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    if (req.body != "") {
        req.checkBody('session_id', 'Invalid session details').notEmpty();
        var mappedErrors = req.validationErrors(true);
    }

    var failmsg = 'No session found.';
    var successmsg = 'Session found.';

    if (mappedErrors == false) {

        var session_id = req.body.session_id;
        db.models.session.associate(db.models);

        // Get session details
        db.models.session.find({
            attributes: ['session_id', 'rider_id','session_start_date', 'session_end_date', 'max_distance', 'measurement_unit', 'workout_type'],

            include: [{
                model: db.models.sprint,
                attributes: [
                    [Sequelize.fn('count', Sequelize.col('sprint_id')), 'total_sprint'],
                    [Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('ST')), 3), 'avg_st'],
                    [Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('RT')), 3), 'avg_rt'],
                    [Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_30')), 3), 'avg_30'],
                    [Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_50')), 3), 'avg_50'],
                    [Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_100')), 3), 'avg_100'],
                    [Sequelize.fn('IF', Sequelize.col('distance_100'), Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_100')), 3), Sequelize.fn('IF', Sequelize.col('distance_50'), Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_50')), 3), Sequelize.fn('IF', Sequelize.col('distance_30'), Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_30')), 3), ''))), 'final_avg']
                ],
                where: { deletedAt: { $eq: null }, status: 1 },
                duplicating: false,
                required: false
            }],
            where: {
                session_id: session_id,
                deletedAt: { $eq: null },
                status: 1
            },
            group: 'session_id'
        }).then(function(findSession) {

            if (findSession) {

                // Sprint array to object
                if (findSession.sprints.length > 0) {
                    findSession.setDataValue('sprints_detail', findSession.dataValues.sprints[0].dataValues);
                } else {
                    findSession.setDataValue('sprints_detail', {});
                }

                delete findSession.dataValues.sprints;

                var max_distance;
                var workout_type;
                var rider_id;
                var currentSessionTotalSprint;
                var currentSessionFinalAvg;
                var currentSessionEndDate;
                var previousSessionFinalAvg;

                if (findSession.dataValues.sprints_detail !== undefined) {
                    currentSessionFinalAvg = findSession.dataValues.sprints_detail.final_avg;
                    currentSessionTotalSprint = findSession.dataValues.sprints_detail.total_sprint;
                }

                currentSessionEndDate = findSession.dataValues.session_end_date;

                // Get coaching tips from (max_distance,rider_id,workout_type,session_id)
                // Compare currentSessionFinalAvg with previousSessionFinalAvg

                max_distance = findSession.dataValues.max_distance;
                workout_type = findSession.dataValues.workout_type;
                rider_id = findSession.dataValues.rider_id;

                if (max_distance && rider_id && workout_type) {

                    db.models.session.find({

                        attributes: ['session_id'],

                        include: [{
                            model: db.models.sprint,
                            attributes: [
                                [Sequelize.fn('COUNT', Sequelize.col('sprint_id')), 'total_sprints'],
                                [Sequelize.fn('IF', Sequelize.col('distance_100'), Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_100')), 3), Sequelize.fn('IF', Sequelize.col('distance_50'), Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_50')), 3), Sequelize.fn('IF', Sequelize.col('distance_30'), Sequelize.fn('ROUND', Sequelize.fn('avg', Sequelize.col('distance_30')), 3), ''))), 'final_avg']
                            ],
                            where: { deletedAt: { $eq: null }, status: 1 },
                            duplicating: false,
                            required: false
                        }],

                        where: {
                            session_id: { $lt: session_id },
                            max_distance: max_distance,
                            rider_id: rider_id,
                            workout_type: workout_type,
                            deletedAt: { $eq: null },
                            status: 1
                        },

                        limit: 1,
                        order: [
                            ['session_id', 'DESC']
                        ],
                        having:{ 
                            'sprints.total_sprints': {
                                $gt: 0
                            }
                        },
                        group: 'session_id'

                    }).then(function(findPreviousSession) {

                        // Session details

                        if (findPreviousSession) {

                            if (findPreviousSession.dataValues.sprints !== undefined && findPreviousSession.dataValues.sprints.length > 0) {
                                previousSessionFinalAvg = findPreviousSession.dataValues.sprints[0].dataValues.final_avg;
                            }

                        }

                        // Get coaching tips
                        if (workout_type && previousSessionFinalAvg && currentSessionFinalAvg && currentSessionTotalSprint) {

                            // 1 :- Greater than 100% , 
                            // 2 :- 100 - 98% , 
                            // 3 :- 95 - 97.9% , 
                            // 4 :- 94.9% or less
                            // a= (nv-ov)*100/nv  FV= 100-a %
                            // nv=new value , ov= Old value , fv= Final value 

                            var sessionPercentage;
                            var whereSessionAvg;

                            sessionPercentage = 100 - ((currentSessionFinalAvg - previousSessionFinalAvg) * 100 / currentSessionFinalAvg);

                            if (sessionPercentage > 100) {
                                whereSessionAvg = 1;
                            } else if (sessionPercentage <= 100 && sessionPercentage >= 98) {
                                whereSessionAvg = 2;
                            } else if (sessionPercentage < 98 && sessionPercentage >= 95) {
                                whereSessionAvg = 3;
                            } else {
                                whereSessionAvg = 4;
                            }


                            db.models.coaching_criteria.find({
                                where: {
                                    workout_type_id: workout_type,
                                    session_avg: whereSessionAvg,
                                    deletedAt: { $eq: null }
                                }
                            }).then(function(coaching_criteria) {

                                if (coaching_criteria) {

                                    // If session completed use post_workout_msg column else use sprint_1_to_6_msg or sprint_7_or_more_msg column

                                    if(currentSessionEndDate){
                                        
                                        findSession.setDataValue('coaching_tips', coaching_criteria.dataValues.post_workout_msg);

                                    } else {

                                        if(currentSessionTotalSprint <= 6){
                                            findSession.setDataValue('coaching_tips', coaching_criteria.dataValues.sprint_1_to_6_msg);
                                        } else {
                                            findSession.setDataValue('coaching_tips', coaching_criteria.dataValues.sprint_7_or_more_msg);
                                        }

                                    }
                                    
                                } else {
                                    findSession.setDataValue('coaching_tips', "");
                                }

                                commonLib.output(res, {
                                    error: false,
                                    data: findSession,
                                    message: successmsg
                                });

                            }).catch(function(err) {
                                commonLib.output(res, {
                                    error: true,
                                    data: null,
                                    message: "Oops! Something went wrong."
                                });
                            });

                        } else {

                            findSession.setDataValue('coaching_tips', "");

                            commonLib.output(res, {
                                error: false,
                                data: findSession,
                                message: successmsg
                            });
                        }


                    }).catch(function(err) {
                        commonLib.output(res, {
                            error: true,
                            data: null,
                            message: "Oops! Something went wrong."
                        });
                    });

                } else {
                    commonLib.output(res, {
                        error: true,
                        data: null,
                        message: 'No Session Found.'
                    });
                }

            } else {
                commonLib.output(res, {
                    error: true,
                    data: null,
                    message: 'No Session Found.'
                });
            }

        }).catch(function(err) {
            commonLib.output(res, {
                error: true,
                data: null,
                message: "Oops! Something went wrong."
            });
        });

    } else {

        var mappedErrors_msg = mappedErrors[Object.keys(mappedErrors)[0]].msg;
        mappedErrors_msg = mappedErrors_msg ? mappedErrors_msg : failmsg;

        commonLib.output(res, {
            error: true,
            data: null,
            message: failmsg,
        });

    }
};
