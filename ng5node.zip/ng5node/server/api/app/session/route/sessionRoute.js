'use strict';

var session = require('../controller/sessionController');

module.exports = function(app) {
    app.post('/app/api/session/start', session.startSession);
    app.post('/app/api/session/end', session.endSession);
    app.post('/app/api/session/details', session.sessionDetails);
    // app.post('/app/api/session/getactivesession', session.getRiderActiveSession);

};