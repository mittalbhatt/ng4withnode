'use strict';

var db = require('../../../../config/sequelize').db;
var generalConfig = require('../../../../config/generalConfig');
var commonLib = require('../../../../lib/common');


/**
 * get all workout
 * @return json
 */

exports.getAllWorkout = function(req, res, next) {
    
  //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error:true,
            data:null,
            msg:'No access. Please login again'
        });
    }

    db.models.workout_type_model
    .findAll({
        attributes: ['id', 'workout_name', 'description'],
        where: {
            deletedAt: { $eq: null },
            status: 1
        }
    })
    .then(function(workout) {
        if(workout) {

            commonLib.output(res,{
                error:false,
                data:workout,
                message:"Workouts found"
            });
            
        } else {
            commonLib.output(res,{
                error:false,
                data:null,
                message:"No workout found"
            });
        }
    })
    .catch(function(err) {
        commonLib.output(res,{
            error: true,
            data: null,
            message: "Oops! Something went wrong."
        });    
    });

};
