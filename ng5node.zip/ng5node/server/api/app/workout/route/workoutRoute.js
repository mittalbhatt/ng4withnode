'use strict';

var workout = require('../controller/workoutController');

module.exports = function(app) {
    app.get('/app/api/workout', workout.getAllWorkout);
};