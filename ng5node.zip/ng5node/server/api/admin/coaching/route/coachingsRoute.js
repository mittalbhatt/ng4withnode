'use strict';

var coaching = require('../controller/coachingsController');
var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();

module.exports = function(app) {
    app.get('/admin/coaching/', coaching.getCoachings);
    app.post('/admin/coaching/editcoaching', multipartMiddleware, coaching.editCoaching);
};