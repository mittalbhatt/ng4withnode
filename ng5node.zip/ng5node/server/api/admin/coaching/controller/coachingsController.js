'use strict';

var db = require('../../../../config/sequelize').db;
var generalConfig = require('../../../../config/generalConfig');
var commonLib = require('../../../../lib/common');
var thumb = require('node-thumbnail').thumb;
var Sequelize = require("sequelize");
var base64Img = require('base64-img');
const fs = require('fs');

/**
 * get all trainers
 * @return json
 */

exports.getCoachings = function(req, res, next) {

    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    db.models.coaching_criteria.associate(db.models);
 
    db.models.coaching_criteria
        .findAll({
            attributes: [
                'id', 
                'workout_type_id',
                'session_avg',
                'sprint_1_to_6_msg', 
                'sprint_7_or_more_msg', 
                'post_workout_msg'
            ],
            where: {
                deletedAt: { $eq: null },
                workout_type_id: { $ne: '1' }
            },
            include: [{
                model: db.models.workout_type_model,
                as: 'workout_details',
                attributes: ['workout_name']
            }]
        })
        .then(function(tips) {
            if (tips) {
                commonLib.output(res, {
                    error: false,
                    data: tips,
                    message: "Tips found"
                });
            } else {
                commonLib.output(res, {
                    error: false,
                    data: null,
                    message: "No tips found"
                });
            }
        })
        .catch(function(err) {
            commonLib.output(res, {
                error: true,
                data: null,
                message: err.message
            });
        });

}


/**
 * Change coaching tips
 */

exports.editCoaching = function(req, res, next){

    var userId = generalConfig.getUserId(req);
    
    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    var failmsg = 'There was some problem updating coaching tips, please try later or contact administrator.';
    var successmsg = 'Coaching has been updated successfully.';

    if (req.body != "") {
        req.checkBody('sprint_1_to_6_msg', 'Sprint 1 to 6 message is required').notEmpty();
        req.checkBody('sprint_7_or_more_msg', 'Sprint 7 or more message is required').notEmpty();
        req.checkBody('post_workout_msg', 'Post workout message is required').notEmpty();
        var mappedErrors = req.validationErrors(true);
        if(mappedErrors){
            res.json({
                error: true,
                data: null,
                message: 'Coaching tips are mandatory, please check empty fields.',
          });
        } else {
            db.models.coaching_criteria
            .findOne({
                attributes: ['id'],
                where: {
                    id:req.body.id,
                    workout_type_id: req.body.workout_type_id
                }
            })
            .then(function(existData){
                if(existData) {
                    var coachingData = req.body;
                    var sprint_1_to_6_msg = coachingData.sprint_1_to_6_msg;
                    var sprint_7_or_more_msg = coachingData.sprint_7_or_more_msg;
                    var post_workout_msg = coachingData.post_workout_msg;
                    db.models.coaching_criteria
                    .update({
                        sprint_1_to_6_msg: sprint_1_to_6_msg,
                        sprint_7_or_more_msg: sprint_7_or_more_msg,
                        post_workout_msg: post_workout_msg
                    }, {
                        where: {
                            id: coachingData.id
                        }
                    })
                    .then(function(update){
                        if(update){
                            res.json({
                                error:false,
                                data:null,
                                message:successmsg
                            });
                        } else {
                            res.json({
                                error:true,
                                data:null,
                                message:failmsg
                            });
                        }
                    })
                    .catch(function(err){
                        res.json({
                            error: true,
                            data: null,
                            message: err +'',
                        });
                    });
                } else {
                    res.json({
                        error: true,
                        data: null,
                        message: 'Given Coaching tips not found.'
                    });
                }
            })
            .catch(function(err) {
                res.json({
                    error: true,
                    data: null,
                    message: err+'',
                });    
            });
        }
    }
}