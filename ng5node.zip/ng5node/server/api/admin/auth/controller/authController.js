'use strict';

var http = require('http');
var url = require('url');
var generalConfig = require('../../../../config/generalConfig');

var crypto = require('crypto');
var db = require('../../../../config/sequelize').db;
var _jade = require('jade');
const fs = require('fs');

/*
   Module : Forgot Password
   Inputs : Email
   Output : Send Reset Password link in email Login.
*/
exports.forgotpassword = function(req, res, next) {

    var email = req.body.useremail;
    db.models.user.find({
        where:{
          email:email, 
          // is_admin:1
        }
    }).then(function(user){
       
        if (!user) {
            res.json({
                error: true,
                data: null,
                message: 'Oops! We could not find your email address.'
            });            
        } else if (user.deletedAt) {
            res.json({
                error: true,
                data: null,
                message: 'Oops! Your account is deleted, please contact administrator.'
            });
        } else if (!user.active) {
            res.json({
                error: true,
                data: null,
                message: 'Oops! Email you have enterd is deactivated, please contact administrator.'
            });
        } else {

            var userTokenGen = new Date().getTime()+user.email;
            var userToken = crypto.createHash('md5').update(userTokenGen).digest('hex');   

            user.update({
              usertoken: userToken
            }).then(function(user) {

                //*/  send reset password link (start)   /*//
                var data = {
                    'name': user.firstname+" "+user.lastname,
                    'titleMsg': generalConfig.resetPassTitle,
                    'bodyMsg': generalConfig.resetPassBody,
                    'siteUrl': generalConfig.siteUrl+"/admin/resetpassword/"+userToken,
                    'logoUrl': generalConfig.logoUrl
                };
                _jade.renderFile(fs.realpathSync( process.cwd() + '/server/template/reset_password.jade'), data, function(err, compiledTemplate){
                    if(err){
                       res.json({
                            error:true,
                            data:'',
                            message:err + ''
                        });
                    }
                    
                    // setup email data with unicode symbols
                    let mailOptions = {
                        from: generalConfig.fromEmail, // sender address
                        to: user.email,
                        subject: generalConfig.resetPassEmailSubject, // Subject line
                        html: compiledTemplate // html body
                    };

                    // send mail with defined transport object
                    generalConfig.transporter.sendMail(mailOptions, (error, info) => {
                        if (error) {
                            res.json({
                                error:true,
                                data:'',
                                message:"Oops! Something went wrong."
                            });
                        }
                        res.json({
                            error: false,
                            data: null,
                            message: 'Reset Password Link has been sent to your email address.'
                        });
                    });
                
                });
            }).catch(function(err) {

                res.json({
                    error: true,
                    data: null,
                    message: "Oops! Something went wrong."
                });
            });
        }

    }).catch(function(err) {
        res.json({
            error: true,
            data: null,
            message: "Oops! Something went wrong."
        });
    });
};

/*
   Module : Reset Password
   Output : Reset Password using reset password token.
*/
exports.resetpassword = function(req, res, next) {

  if (req.body != '')
  {
    req.checkBody('token', 'Reset token is required').notEmpty();
    req.checkBody('password', 'Password is required').notEmpty();
    var mappedErrors = req.validationErrors(true);
  }

  if (mappedErrors == false)
  {
    var token = req.body.token;
    db.models.user.find({
        where:{
          usertoken: token, 
          // is_admin:true
        }
    }).then(function(user){
        if (!user) {
            res.json({
                error: true,
                data: null,
                message: 'Invalid token.'
            });            
        } else {

            var newpassword = generalConfig.encryptPassword(req.body.password);

            user.update({
              password: newpassword,
              usertoken : null
            }).then(function() {

                res.json({
                    error: false,
                    data: null,
                    is_admin: user.is_admin,
                    message: 'Password updated successfully.'
                });

            }).catch(function(err) {

                res.json({
                    error: true,
                    data: null,
                    message: "Oops! Something went wrong."
                });
            });
        }

    }).catch(function(err) {
        res.json({
            error: true,
            data: null,
            message: "Oops! Something went wrong."
        });
    });


  } else {
    res.json({
        error: true,
        data: null,
        message: mappedErrors
    });
  }

};
exports.createpassword = function(req, res, next) {
if (req.body != '')
  {
    req.checkBody('token', 'Token is required').notEmpty();
    req.checkBody('password', 'Password is required').notEmpty();
    var mappedErrors = req.validationErrors(true);
  }

  if (mappedErrors == false)
  {
    var token = req.body.token;
    db.models.user.find({
        where:{
          usertoken: token, 
          is_admin:true
        }
    }).then(function(user){
        if (!user) {
            res.json({
                error: true,
                data: null,
                message: 'Invalid token.'
            });            
        } else {

            var newpassword = generalConfig.encryptPassword(req.body.password);

            user.update({
              password: newpassword,
              usertoken : null
            }).then(function() {

                res.json({
                    error: false,
                    data:null,
                    message: 'Password Created successfully.'
                });

            }).catch(function(err) {

                res.json({
                    error: true,
                    data: null,
                    message: "Oops! Something went wrong."
                });
            });
        }

    }).catch(function(err) {
        res.json({
            error: true,
            data: null,
            message: "Oops! Something went wrong."
        });
    });
  } else {
    res.json({
        error: true,
        ata: null,
        message: mappedErrors
    });
  }
};

exports.emailverification = function(req, res, next) {

  if (req.body != '')
  {
    req.checkBody('token', 'Token is required').notEmpty();
    var mappedErrors = req.validationErrors(true);
  }

  if (mappedErrors == false)
  {
    var token = req.body.token;
    db.models.user.find({
        where:{
          emailverificationtoken: token, 
          // is_admin:true
        }
    }).then(function(user){
        if (!user) {
            res.json({
                error: true,
                data: null,
                message: 'Invalid token OR email address already verified.'
            });            
        } else {
            
            user.update({
              emailverificationtoken : null
            }).then(function() {

                res.json({
                    error: false,
                    data: null,
                    is_admin: user.is_admin,
                    message: 'Email Address Verified Successfully.'
                });

            }).catch(function(err) {

                res.json({
                    error: true,
                    data: null,
                    message: "Oops! Something went wrong."
                });
            });
        }

    }).catch(function(err) {
        res.json({
            error: true,
            data: null,
            message: "Oops! Something went wrong."
        });
    });


  } else {
    res.json({
        error: true,
        data: null,
        message: mappedErrors
    });
  }

};