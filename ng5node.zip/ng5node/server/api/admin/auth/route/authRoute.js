'use strict';

var adminAuth = require('../controller/authController');

module.exports = function(app) {
    
    app.post('/admin/forgotpassword', adminAuth.forgotpassword);
    app.post('/admin/resetpassword', adminAuth.resetpassword);
    app.post('/admin/createpassword', adminAuth.createpassword);
    app.post('/admin/emailverification', adminAuth.emailverification);
};