'use strict';

var db = require('../../../../config/sequelize').db;
var generalConfig = require('../../../../config/generalConfig');
var commonLib = require('../../../../lib/common');
var thumb = require('node-thumbnail').thumb;
var Sequelize = require("sequelize");
var base64Img = require('base64-img');
const fs = require('fs');

/**
 * get all trainers
 * @return json
 */

exports.getTrainers = function(req, res, next) {

    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    db.models.user
        .findAll({
            attributes: ['id', 'email', 'firstname', 'lastname', 'profile_image', 'mobile_no', 'is_admin', 'active', 'is_fb_user', 'fb_id'],
            where: {
                deletedAt: { $eq: null },
                is_admin: 0
            }
        })
        .then(function(users) {
            if (users) {
                commonLib.getTrainerImage(users, function() {
                    commonLib.output(res, {
                        error: false,
                        data: users,
                        message: "Trainers found"
                    });
                });

            } else {
                commonLib.output(res, {
                    error: false,
                    data: null,
                    message: "No trainers found"
                });
            }
        })
        .catch(function(err) {
            commonLib.output(res, {
                error: true,
                data: null,
                message: "Oops! Something went wrong."
            });
        });

};

/**
 * get all trainer
 * @return json 
 */

exports.getTrainer = function(req, res, next) {

    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    db.models.user
        .find({
            attributes: ['id', 'email', 'firstname', 'lastname', 'profile_image', 'mobile_no', 'is_admin', 'active', 'is_fb_user', 'fb_id'],
            where: {
                id : req.params.id,
                deletedAt: { $eq: null },
                is_admin: 0
            }
        })
        .then(function(user) {
            if (user) {
                commonLib.getTrainerImage(user, function() {
                    commonLib.output(res, {
                        error: false,
                        data: user,
                        message: "Trainers found"
                    });
                });

            } else {
                commonLib.output(res, {
                    error: false,
                    data: null,
                    message: "No trainers found"
                });
            }
        })
        .catch(function(err) {
            commonLib.output(res, {
                error: true,
                data: null,
                message: "Oops! Something went wrong."
            });
        });

};

/**
 * Change Trainer status
 */
exports.changeStatus = function(req, res, next) {
    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }
    
    db.models.user.findOne({
        where: { id : req.body.id,
                deletedAt: { $eq: null },
                is_admin: 0 }
    }).then(function(user) {
        if (user) {console.log(req.body.active);
            db.models.user.update({
                active: (req.body.active == true)?'1':'0'
            }, { where: {
                 id : req.body.id,
                 deletedAt: { $eq: null },
                 is_admin: 0}
            }).then(function(updateUser) {
                if (updateUser) {
                    res.json({
                        error: false,
                        data: null,
                        message: "Status updated successfully"
                    });
                } else {
                    res.json({
                        error: true,
                        data: null,
                        message: "Error updating user status"
                    });
                }
            }).catch(function(err) {
                res.json({
                    error: true,
                    data: null,
                    message: "Error updating user status"+err
                });
            });
        } else {
            res.json({
                error: false,
                data: null,
                message: "User not found"
            });
        }
    }).catch(function(err) {
        res.json({
            error: true,
            data: null,
            message: "Error updating user status"
        });
    });
}


/**
 * Change Trainer information
 */

exports.editTrainer = function(req, res, next){

    var userId = generalConfig.getUserId(req);
    
    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    var failmsg = 'There was some problem updating trainer profile, please try later or contact administrator.';
    var successmsg = 'Trainer profile has been updated successfully.';

    if (req.body != "") {
        req.checkBody('firstname', 'First Name is required').notEmpty();
        req.checkBody('lastname', 'Last Name is required').notEmpty();
        req.checkBody('email', 'Email is required').notEmpty();
        var mappedErrors = req.validationErrors(true);
        if(mappedErrors){
            res.json({
                error: true,
                data: null,
                message: failmsg,
          });
        }
    }
    db.models.user
	.findOne({
        attributes: ['id','profile_image'],
		where: {
            id:req.body.id
		}
    })
    .then(function(existData){
        /*if(exist){
            res.json({
                error: true,
                data: null,
                message: 'Email already in use. Please chooes another email'
            });
        } else {*/
            var trainerData = req.body;
            var firstname = trainerData.firstname;
            var lastname = trainerData.lastname;
            var email = trainerData.email;
            var mobile_no = trainerData.mobile_no;
            var profile_image = existData.profile_image;
            if(trainerData.profileDelete == 'true')
            {
                commonLib.removeProfilePicture(profile_image);
                profile_image = '';
            }
            if (req.files && req.files.profile_image) {
                var profilepicture = req.files.profile_image;
                commonLib.storeProfilePicture(profilepicture, trainerData.id, function(result) {
                    if(result.status) {
                        if(profile_image) {
                            commonLib.removeProfilePicture(profile_image);
                        }
                        //Create thumb
                        thumb({
                        source: generalConfig.filesPath.userPicture+result.filename, // could be a filename: dest/path/image.jpg 
                        destination: generalConfig.filesPath.userPicture,
                        prefix: 'thumb100_',
                        suffix: '',
                        width: 100,
                        concurrency: 4
                        });
                        thumb({
                        source: generalConfig.filesPath.userPicture+result.filename, // could be a filename: dest/path/image.jpg 
                        destination: generalConfig.filesPath.userPicture,
                        prefix: 'thumb768_',
                        suffix: '',
                        height: 768,
                        concurrency: 4
                        });
                        profile_image = result.filename;
                        db.models.user
                        .update({
                            firstname: firstname,
                            lastname: lastname,
                            email: email,
                            mobile_no: mobile_no,
                            profile_image: profile_image
                        }, {
                            where: {
                                id: trainerData.id
                            }
                        })
                        .then(function(update){
                            if(update){
                                res.json({
                                    error:false,
                                    data:null,
                                    message:successmsg
                                });
                            } else {
                                res.json({
                                    error:true,
                                    data:null,
                                    message:failmsg
                                });
                            }
                        })
                        .catch(function(err){
                            res.json({
                                error: true,
                                data: null,
                                message: err +'',
                            });
                        });
                    } else {
                        return res.json({
                            error: true,
                            data: null,
                            message: result.message +'',
                        });
                    }
                });
            } else {
                db.models.user
                .update({
                    firstname: firstname,
                    lastname: lastname,
                    email: email,
                    mobile_no: mobile_no,
                    profile_image: profile_image
                }, {
                    where: {
                        id: trainerData.id
                    }
                })
                .then(function(update){
                    if(update){
                        res.json({
                            error:false,
                            data:null,
                            message:successmsg
                        });
                    } else {
                        res.json({
                            error:true,
                            data:null,
                            message:failmsg
                        });
                    }
                })
                .catch(function(err){
                    res.json({
                        error: true,
                        data: null,
                        message: err +'',
                    });
                });
            }
       /* }*/
    })
    .catch(function(err) {
        res.json({
            error: true,
            data: null,
            message: err+'',
        });
    });
    //var data = req.body;
    //db.models.user.update()
}