'use strict';

var trainer = require('../controller/trainersController');
var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();

module.exports = function(app) {
    app.get('/admin/trainer/', trainer.getTrainers);
    app.get('/admin/trainer/:id', trainer.getTrainer);
    app.post('/admin/trainer/status', trainer.changeStatus);
    app.post('/admin/trainer/edittrainer', multipartMiddleware, trainer.editTrainer);
};