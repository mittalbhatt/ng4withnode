'use strict';

var db = require('../../../../config/sequelize').db;
var generalConfig = require('../../../../config/generalConfig');
var commonLib = require('../../../../lib/common');
var thumb = require('node-thumbnail').thumb;
var Sequelize = require("sequelize");
var base64Img = require('base64-img');
const fs = require('fs');

/**
 * get all trainers
 * @return json
 */

exports.getRiders = function(req, res, next) {

    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    db.models.rider.associate(db.models);

    db.models.rider
        .findAll({
            attributes: [
                'rider_id', 
                'trainer_id',
                'email', 
                'firstname', 
                'lastname', 
                'profile_image', 
                'mobile_no', 
                'active'
            ],
            where: {
                deletedAt: { $eq: null }
            },
            include: [{
                model: db.models.user,
                as: 'trainer_details',
                attributes: ['firstname', 'lastname']
            }]
        })
        .then(function(riders) {
            if (riders) {
                commonLib.getRiderImage(riders, function() {
                    commonLib.output(res, {
                        error: false,
                        data: riders,
                        message: "Riders found"
                    });
                });

            } else {
                commonLib.output(res, {
                    error: false,
                    data: null,
                    message: "No riders found"
                });
            }
        })
        .catch(function(err) {
            commonLib.output(res, {
                error: true,
                data: null,
                message: err.message
            });
        });

}

/**
 * get all trainer
 * @return json
 */

exports.getRider = function(req, res, next) {

    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    db.models.rider
        .find({
            attributes: [
                'rider_id', 
                'trainer_id',
                'email', 
                'firstname', 
                'lastname', 
                'profile_image', 
                'height',
                'weight',
                'age',
                'mobile_no', 
                'active'
            ],
            where: {
                rider_id : req.params.id,
                deletedAt: { $eq: null }
            }
        })
        .then(function(rider_detail) {
            if (rider_detail) {
                commonLib.getRiderImage(rider_detail, function() {
                    commonLib.output(res, {
                        error: false,
                        data: rider_detail,
                        message: "Rider found"
                    });
                });

            } else {
                commonLib.output(res, {
                    error: false,
                    data: null,
                    message: "No rider found"
                });
            }
        })
        .catch(function(err) {
            commonLib.output(res, {
                error: true,
                data: null,
                message: "Oops! Something went wrong."
            });
        });

}

/**
 * get Riders by Trainers
**/

exports.getRiderByTrainer = function(req, res, next) {
    var userId = generalConfig.getUserId(req);
    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }
    db.models.rider.associate(db.models);
    db.models.rider
    .findAll({
        attributes: [
            'rider_id',
            'trainer_id',
            'email', 
            'firstname', 
            'lastname', 
            'profile_image', 
            'mobile_no', 
            'active'
        ],
        where: {
            trainer_id : req.params.id,
            deletedAt: { $eq: null }
        },
        include: [{
            model: db.models.user,
            as: 'trainer_details',
            attributes: ['firstname', 'lastname']
        }]
    })
    .then(function(user) {
        if (user) {
            commonLib.getRiderImage(user, function() {
                commonLib.output(res, {
                    error: false,
                    data: user,
                    message: "Riders found"
                });
            });
        } else {
            commonLib.output(res, {
                error: false,
                data: null,
                message: "No riders found"
            });
        }
    })
    .catch(function(err) {
        commonLib.output(res, {
            error: true,
            data: null,
            message: err.message
        });
    });

}

/**
 * Change Trainer status
 */
exports.changeStatus = function(req, res, next) {
    //Get userId from request
    var userId = generalConfig.getUserId(req);

    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }
    
    db.models.rider.findOne({
        where: { 
                rider_id : req.body.id,
                deletedAt: { $eq: null }
             }
    }).then(function(user) {
        if (user) {console.log(req.body.active);
            db.models.rider.update({
                active: (req.body.active == true)?'1':'0'
            }, { 
                where: {
                    rider_id : req.body.id,
                    deletedAt: { $eq: null }
                }
            }).then(function(updateUser) {
                if (updateUser) {
                    res.json({
                        error: false,
                        data: null,
                        message: "Status updated successfully"
                    });
                } else {
                    res.json({
                        error: true,
                        data: null,
                        message: "Error updating rider status"
                    });
                }
            }).catch(function(err) {
                res.json({
                    error: true,
                    data: null,
                    message: "Error updating rider status"+err
                });
            });
        } else {
            res.json({
                error: false,
                data: null,
                message: "Rider not found"
            });
        }
    }).catch(function(err) {
        res.json({
            error: true,
            data: null,
            message: "Error updating rider status"
        });
    });
}


/**
 * Change Trainer information
 */

exports.editRider = function(req, res, next){

    var userId = generalConfig.getUserId(req);
    
    if (!userId) {
        return res.json({
            error: true,
            data: null,
            msg: 'No access. Please login again'
        });
    }

    var failmsg = 'There was some problem updating rider profile, please try later or contact administrator.';
    var successmsg = 'Rider profile has been updated successfully.';

    if (req.body != "") {
        req.checkBody('firstname', 'First Name is required').notEmpty();
        req.checkBody('trainer_id', 'Invalid trainer details').notEmpty();
        req.checkBody('lastname', 'Last Name is required').notEmpty();
        req.checkBody('email', 'Email is required').notEmpty();
        var mappedErrors = req.validationErrors(true);
        if(mappedErrors){
            res.json({
                error: true,
                data: null,
                message: failmsg,
          });
        }
    }
    db.models.rider
	.findOne({
        attributes: ['rider_id','profile_image'],
		where: {
            rider_id:req.body.rider_id,
            trainer_id: req.body.trainer_id
		}
    })
    .then(function(existData){
        db.models.rider
        .find({ 
            where: {
                email: req.body.email,
                trainer_id: req.body.trainer_id,
                rider_id:{ $ne:req.body.rider_id }
            }
        })
        .then(function(exist){
            if(exist){
                res.json({
                    error: true,
                    data: null,
                    message: 'Email already in use. Please chooes another email'
                });
            } else {
                var riderData = req.body;
                var firstname = riderData.firstname;
                var lastname = riderData.lastname;
                var email = riderData.email;
                var mobile_no = riderData.mobile_no;
                var age = riderData.age;
                var weight = riderData.weight;
                var profile_image = existData.profile_image;
                if(riderData.height_feet != '' && riderData.height_inch != ''){
                    var height = riderData.height_feet+'.'+riderData.height_inch;
                } else if(riderData.height_feet != '') {
                    var height = riderData.height_feet;
                } else {
                    var height = null;
                }
                if(riderData.profileDelete == 'true')
                {
                    commonLib.removeRiderPicture(profile_image);
                    profile_image = '';
                }
                if (req.files && req.files.profile_image) {
                    var profilepicture = req.files.profile_image;
                    commonLib.storeRiderPicture(profilepicture, riderData.rider_id, function(result) {
                        if(result.status) {
                            if(profile_image) {
                                commonLib.removeRiderPicture(profile_image);
                            }
                            //Create thumb
                            thumb({
                            source: generalConfig.filesPath.riders_profilepicture+result.filename, // could be a filename: dest/path/image.jpg 
                            destination: generalConfig.filesPath.riders_profilepicture,
                            prefix: 'thumb100_',
                            suffix: '',
                            width: 100,
                            concurrency: 4
                            });
                            thumb({
                            source: generalConfig.filesPath.riders_profilepicture+result.filename, // could be a filename: dest/path/image.jpg 
                            destination: generalConfig.filesPath.riders_profilepicture,
                            prefix: 'thumb768_',
                            suffix: '',
                            height: 768,
                            concurrency: 4
                            });
                            profile_image = result.filename;
                            db.models.rider
                            .update({
                                firstname: firstname,
                                lastname: lastname,
                                email: email,
                                mobile_no: mobile_no,
                                age: age,
                                weight: weight,
                                height: height,
                                profile_image: profile_image
                            }, {
                                where: {
                                    rider_id: riderData.rider_id
                                }
                            })
                            .then(function(update){
                                if(update){
                                    res.json({
                                        error:false,
                                        data:null,
                                        message:successmsg
                                    });
                                } else {
                                    res.json({
                                        error:true,
                                        data:null,
                                        message:failmsg
                                    });
                                }
                            })
                            .catch(function(err){
                                res.json({
                                    error: true,
                                    data: null,
                                    message: err +'',
                                });
                            });
                        } else {
                            return res.json({
                                error: true,
                                data: null,
                                message: result.message +'',
                            });
                        }
                    });
                } else {
                    db.models.rider
                    .update({
                        firstname: firstname,
                        lastname: lastname,
                        email: email,
                        mobile_no: mobile_no,
                        age: age,
                        weight: weight,
                        height: height,
                        profile_image: profile_image
                    }, {
                        where: {
                            rider_id: riderData.rider_id
                        }
                    })
                    .then(function(update){
                        if(update){
                            res.json({
                                error:false,
                                data:null,
                                message:successmsg
                            });
                        } else {
                            res.json({
                                error:true,
                                data:null,
                                message:failmsg
                            });
                        }
                    })
                    .catch(function(err){
                        res.json({
                            error: true,
                            data: null,
                            message: err +'',
                        });
                    });
                }
            }
        })
        .catch(function(err) {
            res.json({
                error: true,
                data: null,
                message: err+'',
            });
        });
    })
    .catch(function(err) {
        res.json({
            error: true,
            data: null,
            message: err+'',
        });    
    });
    //var data = req.body;
    //db.models.user.update()
}