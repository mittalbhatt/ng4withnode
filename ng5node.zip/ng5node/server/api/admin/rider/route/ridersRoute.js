'use strict';

var rider = require('../controller/ridersController');
var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();

module.exports = function(app) {
    app.get('/admin/rider/', rider.getRiders);
    app.get('/admin/rider/:id', rider.getRider);
    app.post('/admin/rider/status', rider.changeStatus);
    app.post('/admin/rider/editrider', multipartMiddleware, rider.editRider);
    app.get('/admin/rider/bytrainer/:id', rider.getRiderByTrainer);
};