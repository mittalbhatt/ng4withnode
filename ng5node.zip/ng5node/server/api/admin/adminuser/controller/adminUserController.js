'use strict';

var db = require('../../../../config/sequelize').db;
var generalConfig = require('../../../../config/generalConfig');
var commonLib = require('../../../../lib/common');
var thumb = require('node-thumbnail').thumb;
var Sequelize = require("sequelize");

/*
 * Get Profile
 */
exports.getProfile = function (req, res, next){
    var userId = generalConfig.getUserId(req);
    if (!userId) {
        return res.json({
                    error:true,
                    data:null,
                    msg:'No access. Please login again'
        		});
    }
    
    db.models.user
    .findOne({
        attributes: [
            'firstname',
            'lastname',
            'email',
            'profile_image',
            [db.fn("concat", generalConfig.blankUserImage), 'blank_user_image'],
            [db.fn("concat", generalConfig.blankUserImageThumb), 'blank_user_image_thumb']
        ],
        where: {
            id: userId
        }
    })
    .then(function(user) {
        commonLib.getProfileImage(user, function() {
            res.json({
                error:false,
                data:user,
                message:null
            });
        });
    })
    .catch(function(err) {
        res.json({
            error: true,
            data: null,
            message: err +''
        });    
    });
};

/**
 * update login user profile
 * @return json
 */
exports.updateProfile = function(req, res, next) {
    
  //Get userId from request
    var userId = generalConfig.getUserId(req);
    if (!userId) {
        return res.json({
                    error:true,
                    data:null,
                    msg:'No access. Please login again'
        		});
    }
    if (req.body != "") {
	req.checkBody('firstname', 'First Name is required').notEmpty();
	req.checkBody('lastname', 'Last Name is required').notEmpty();
	req.checkBody('email', 'Email is required').notEmpty();
	var mappedErrors = req.validationErrors(true);
    }
    var failmsg = 'There was some problem updating profile, please try later or contact administrator.';
    var successmsg = 'Profile has been updated successfully.';

    if (mappedErrors == false) {

	var updateuser = req.body;
    
	db.models.user
	.findOne({
        attributes: ['id','firstname','lastname','email','profile_image'],
		where: {
		  id: userId
		}
	})
	.then(function(user) {
        db.models.user.find({
            where: {
                email: req.body.email,
                id:{ $ne:user.id }
            }
        }).then(function(emailExist){
            if(emailExist)
            {
                res.json({
                    error: true,
                    data: null,
                    message: 'Email already in use. Please chooes another email'
                });
            }
            else {
                user.firstname  = updateuser.firstname;
                user.lastname   = updateuser.lastname;
                user.email      = updateuser.email;
                
                if(updateuser.changePassword == 'true') {
                        user.password = generalConfig.encryptPassword(updateuser.newpassword);		  	
                }
                if(req.body.profileDelete == 'true')
                {
                    commonLib.removeProfilePicture(user.profile_image);
                    user.profile_image = null;
                }
                if (req.files && req.files.profile_image) {
                    var profilepicture = req.files.profile_image;
                    commonLib.storeProfilePicture(profilepicture, user.id, function(result) {
                        if(result.status) {
                            if(user.profile_image) {
                                commonLib.removeProfilePicture(user.profile_image);
                            }

                            //Create thumb
                            thumb({
                            source: generalConfig.filesPath.userPicture+result.filename, // could be a filename: dest/path/image.jpg 
                            destination: generalConfig.filesPath.userPicture,
                            prefix: 'thumb100_',
                            suffix: '',
                            width: 100,
                            concurrency: 4
                            });

                            thumb({
                            source: generalConfig.filesPath.userPicture+result.filename, // could be a filename: dest/path/image.jpg 
                            destination: generalConfig.filesPath.userPicture,
                            prefix: 'thumb768_',
                            suffix: '',
                            height: 768,
                            concurrency: 4
                            });
                            
                            user.profile_image = result.filename;
                                user.save().then(function(user) {
                                    res.json({
                                        error:false,
                                        data:null,
                                        message:successmsg
                                    });
                                })
                                .catch(function(err) {
                                        res.json({
                                            error: true,
                                            data: null,
                                            message: err + ''
                                        });
                                });

                        } else {

                            return res.json({
                                error: true,
                                data: null,
                                message: result.message +'',
                            });
                        }
                });

                } else {
                    user.save().then(function(user) {
                        res.json({
                            error:false,
                            data:null,
                            message:successmsg
                        });    
                    })
                    .catch(function(err) {
                            res.json({
                                error: true,
                                data: null,
                                message: err +'',
                            });
                    });
                }
            }
        })
        .catch(function(err) {
                res.json({
                    error: true,
                    data: null,
                    message: err+'',
                });    
        });
    })
    .catch(function(err) {
        res.json({
            error: true,
            data: null,
            message: err+'',
        });    
    });
  } else {
      res.json({
            error: true,
            data: null,
            message: failmsg,
      });
  }
};