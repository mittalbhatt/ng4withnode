'use strict';

var user = require('../controller/adminUserController');
var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();

module.exports = function(app) {
    app.get('/api/admin/profile/', user.getProfile);
    app.post('/api/admin/profile', multipartMiddleware, user.updateProfile);
};