'use strict';
var jwt = require('jwt-simple');
var bodyParser = require("body-parser");  
var localStorage = require('localStorage');
var generalConfig = require('./config/generalConfig');
var moment = require('moment');
var passport = require("./config/passport.js")(); 


module.exports = function(app) {
    
    app.use(bodyParser.json());  
    app.use(passport.initialize());

    app.all('/admin/signin',function(req, res) {  
       
        if (req.body.username.email && req.body.password && req.body.username.isadmin == 1) {
            var email = req.body.username.email;
            var password = req.body.password;
           

            passport.validateAdminEmailPass(email,password,function(res1){

                if(res1){

                    if(res1.error == false){

                        generalConfig.generateJwtToken(res1.data.id,function(res2){
                            res.json({
                                newToken: res2.newToken,
                                message: res1.message,
                                error: false
                            });
                        });

                    } else {
                        res.json({
                            message: res1.message,
                            error: true
                        });
                    }

                } else {
                    res.json({
                        message: 'Some issue occurred.',
                        error: true
                    });
                }

            });

        } else {
            res.json({
                message: "User credentials are invalid",
                error: true
            });
        }
    });

    
    app.all('/api/admin/*',passport.authenticate(), function(req, res, next) {
        next();
    });

    // app.get("/api/admin/test", function(req, res) {  
        
    //     if(res.req.user.token_expired == true){
    //         res.json({message:'Success',newToken:res.req.user.newToken});
    //     } else {
    //         res.json({message:'Success'});    
    //     }
        
    // });
    
    var adminAuthRoute = require('./api/admin/auth/route/authRoute.js');
    new adminAuthRoute(app);

    var adminUserRoute = require('./api/admin/adminuser/route/adminUserRoute.js');
    new adminUserRoute(app);

    var trainersRoute = require('./api/admin/trainer/route/trainersRoute.js');
    new trainersRoute(app);

    var ridersRoute = require('./api/admin/rider/route/ridersRoute.js');
    new ridersRoute(app);

    var coachingsRoute = require('./api/admin/coaching/route/coachingsRoute.js');
    new coachingsRoute(app);
    
    
    app.use(function(err, req, res, next) {
        console.error(err);
        var msg = {
            error_code: err.error,
            message:((err.message)?err.message : err.error_description),
        };
        if(err.code == 401 || err.code == 503)
        {
            res.status(err.code).send(msg);
        }
        else {
            return res.json({
                code: err.code,
                status: 'fail',
                error: true,
                message:((err.message)?err.message : err.error_description),
            });  
        }
    });
   
};