module.exports = {
    //MYSQL Database configuration    
    modelsDir : {
        path : __dirname + '/../models',
    },
   "db": {
        "username": "root",
        "password": "root",
        "database": "bmx",
        "host": "localhost",
        "dialect": "mysql",
        "port": ""
    },
    "production": {
        "username": "root",
        "password": "root",
        "database": "bmx",
        "host": "localhost",
        "dialect": "mysql",
        "port": ""
    }
};

// module.exports = {
//     //MYSQL Database configuration    
//     modelsDir : {
//         path : __dirname + '/../models',
//     },
//    "db": {
//         "username": "bmx",
//         "password": "r2gJxSvKu{>+z#?W",
//         "database": "bmx",
//         "host": "localhost",
//         "dialect": "mysql",
//         "port": "3306"
//     },
//     "production": {
//         "username": "bmx",
//         "password": "r2gJxSvKu{>+z#?W",
//         "database": "bmx",
//         "host": "localhost",
//         "dialect": "mysql",
//         "port": "3306"
//     }
// };
