
/*Crypto use for Encryption and Decryption of string */
var crypto = require('crypto');
var jwt = require('jwt-simple');
const nodemailer = require('nodemailer');
var moment = require('moment');

var siteUrl = 'http://192.168.3.143/demopro/bmx/dist/#';
var serverUrl = 'http://192.168.3.143:9090';
var logoUrl = 'http://192.168.3.143/demopro/bmx/dist';

// var siteUrl = 'http://bmxtechnology.com/#';
// var serverUrl = 'http://bmxtechnology.com:9090';
// var logoUrl = 'http://bmxtechnology.com/';

var saltKey = 'f196e5f12f16352f9c3db5caf8807ddc';
var secretKey = 'X2sedo2Bnc';

var jwtSession = { session: false }

var table_prefix = 'bmx_';

var paths = {
    userPicture: "uploads/user_profilepicture/",
    riders_profilepicture: "uploads/riders_profilepicture/",
    help_pdf_file:serverUrl+"/uploads/help/pdf/help.pdf"
};

var validImageExtensions = ['.png','.jpg','.jpeg','gif'];
var validImageSize = 5000000;

var fromEmail = 'milansoftweb@gmail.com';

var resetPassEmailSubject = 'BMX - Reset Password Detail';
var resetPassTitle = 'Reset Password';
var resetPassBody = 'Please click on below link OR copy paste into browser to reset password.';

var emailVerificationSubject = 'BMX - Email Address Verification';
var emailVerificationTitle = 'Email Address Verification';
var emailVerificationBody = 'Please click on below link OR copy paste into browser to confirm your email address.';

// Email - create reusable transporter object using the default SMTP transport
var transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 587,
    secure: false, // secure:true for port 465, secure:false for port 587
    auth: {
        user: 'milansoftweb@gmail.com',
        pass: 'softweb#123'
    },
    tls: { rejectUnauthorized: false }
});

var blankUserImageThumb = serverUrl + '/uploads/user_profilepicture/thumb100_noimage.png'; 
var blankUserImage = serverUrl + '/uploads/user_profilepicture/thumb768_noimage.png';

function authenticate(plainText, hashedPassword) {
    return encryptPassword(plainText, saltKey) === hashedPassword;
}

function encryptPassword(password) {
    if (!password) return '';
    return crypto.pbkdf2Sync(password, saltKey, 10000, 64).toString('hex');
}

function generateJwtToken(id,res){

    if(id){

        // var expireDate = moment().add(5, 'hours').valueOf();
        // var expireDate = moment().add(1, 'minutes').valueOf();
        var expireDate = moment().add(12, 'months').valueOf();

        var payload = {
            id: id,
            expDate:expireDate
        };

        res({newToken:jwt.encode(payload, secretKey)});
        
    } else {
        res({newToken:null});
    }

}

/**
 * Get userId from token
 */
function getUserId(req) {
    if (req.headers.authorization) {
        var accesstoken = req.headers.authorization.split(" ")[1];
        var obj = jwt.decode(accesstoken, secretKey);
        return obj.id;
    } else {
        return null;
    }
}

module.exports = {
   
    cryptoAuthentication: {
        crypto: crypto,
        algorithm: 'aes-256-ctr',
        password: 'cnhzeXN0ZW0'
    },
    cryptKey: 'cnhzeXN0ZW0',
    authenticate: authenticate,
    encryptPassword: encryptPassword,
    saltKey: saltKey,
    secretKey: secretKey,
    jwtSession: jwtSession,
    getUserId: getUserId,
    siteUrl:siteUrl,
    serverUrl: serverUrl,
    logoUrl: logoUrl,
    table_prefix: table_prefix,
    filesPath: paths,
    validImageExtensions: validImageExtensions,
    validImageSize: validImageSize,
    blankUserImageThumb: blankUserImageThumb,
    blankUserImage: blankUserImage,
    transporter: transporter,
    fromEmail: fromEmail,
    resetPassEmailSubject: resetPassEmailSubject,
    resetPassTitle: resetPassTitle,
    resetPassBody: resetPassBody,
    generateJwtToken: generateJwtToken,
    emailVerificationSubject: emailVerificationSubject,
    emailVerificationTitle: emailVerificationTitle,
    emailVerificationBody: emailVerificationBody
};