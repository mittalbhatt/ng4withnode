'use strict';
var jwt = require('jwt-simple');
var bodyParser = require("body-parser");  
var generalConfig = require('./config/generalConfig');
var moment = require('moment');
var passport = require("./config/passport.js")(); 


module.exports = function(app) {
    
    app.use(bodyParser.json());  
    app.use(passport.initialize());

    // User signin
    app.post('/app/signin',function(req, res) {  
        
        var email = req.body.email;
        var password = req.body.password?req.body.password:null;
        var authmode = req.body.authmode?req.body.authmode:null;
        var userdetails = req.body.userdetails?req.body.userdetails:null;

        if (email && (((!authmode || authmode == '') && password) || (authmode == 'facebook' && userdetails))) {
            
            passport.validateAppEmailPass(email,password,authmode,userdetails,function(res1){

                if(res1){

                    if(res1.error == false){
                        
                        generalConfig.generateJwtToken(res1.data.id,function(res2){
                            res.json({
                                newToken: res2.newToken,
                                message: res1.message,
                                data:res1.data,
                                error: false
                            });
                        });

                    } else {
                        res.json({
                            message: res1.message,
                            error: true
                        });
                    }

                } else {
                    res.json({
                        message: 'Oops! Something went wrong.',
                        error: true
                    });
                }

            });

        } else {
            res.json({
                message: "Oops! User credentials are invalid",
                error: true
            });
        }
    });

    // User register with password
    app.post('/app/register',function(req, res) {  
        
        var email = req.body.email;
        var password = req.body.password?req.body.password:null;
        var userdetails = req.body.userdetails?req.body.userdetails:null;

        if (email && password) {
            
            passport.registerAppUserWithEmailPass(email,password,userdetails,function(res1){

                if(res1){

                    if(res1.error == false){
                        
                        generalConfig.generateJwtToken(res1.data.id,function(res2){
                            res.json({
                                newToken: res2.newToken,
                                message: res1.message,
                                data:res1.data,
                                error: false
                            });
                        });

                    } else {
                        res.json({
                            message: res1.message,
                            error: true
                        });
                    }

                } else {
                    res.json({
                        message: 'Oops! Something went wrong.',
                        error: true
                    });
                }

            });

        } else {
            res.json({
                message: "Oops! Something went wrong.",
                error: true
            });
        }
    });

    // forgot password
    app.post('/app/forgotpassword',function(req, res) {  
        
        var email = req.body.email;
        
        if (email) {
            
            passport.forgotPassword(email,function(res1){

                if(res1){

                    res.json({
                        message: res1.message,
                        error: res1.error
                    });

                } else {
                    res.json({
                        message: 'Oops! Something went wrong.',
                        error: true
                    });
                }

            });

        } else {
            res.json({
                message: "Oops! Something went wrong.",
                error: true
            });
        }
    });

    // help url

    app.get('/app/help/pdf',function(req, res) {  
        
        res.json({ 
            message: "PDF Found.",
            data: {
               url: generalConfig.filesPath.help_pdf_file,
            },
            error: false
        });
        
    });

    // All "/app/api" web services pass through passport.authenticate()
    app.all('/app/api/*',passport.authenticate(), function(req, res, next) {
        next();
    });

    var trainersRoute = require('./api/app/trainer/route/trainersRoute.js');
    new trainersRoute(app);
    
    var ridersRoute = require('./api/app/riders/route/ridersRoute.js');
    new ridersRoute(app);

    var workoutRoute = require('./api/app/workout/route/workoutRoute.js');
    new workoutRoute(app);

    var sessionRoute = require('./api/app/session/route/sessionRoute.js');
    new sessionRoute(app);

    var sprintRoute = require('./api/app/sprint/route/sprintRoute.js');
    new sprintRoute(app);

    
    //Express error handler (Every error will pass form this function)    
    app.use(function(err, req, res, next) {
        console.error(err);
        var msg = {
            error_code: err.error,
            message:((err.message)?err.message : err.error_description),
        };
        if(err.code == 401 || err.code == 503)
        {
            res.status(err.code).send(msg);
        }
        else {
            return res.json({
                code: err.code,
                error: true,
                errorTypeToken: true,
                message:((err.message)?err.message : err.error_description),
            });  
        }
    });
   
};