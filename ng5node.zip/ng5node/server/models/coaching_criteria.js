var generalConfig = require('../config/generalConfig');
module.exports = function(sequelize, DataTypes) {

    var coaching_criteria = sequelize.define('coaching_criteria', 
        {
            id: {
                type: DataTypes.INTEGER,
                allowNull: false,
                primaryKey: true,
                autoIncrement: true
            },
            workout_type_id: DataTypes.INTEGER,
            session_avg: DataTypes.INTEGER,
            sprint_1_to_6_msg: DataTypes.TEXT,
            sprint_7_or_more_msg: DataTypes.TEXT,
            post_workout_msg: DataTypes.TEXT,
            deletedAt: DataTypes.DATE
        }, 
        {
            freezeTableName: true,
            tableName: generalConfig.table_prefix + 'coaching_criteria',
            classMethods: {
                associate: function(models) {
                    coaching_criteria.belongsTo(models.workout_type_model, {
                        foreignKey: 'workout_type_id',
                        as: 'workout_details'                        
                    })
                }
            }
        }
    );

    return coaching_criteria;
};
