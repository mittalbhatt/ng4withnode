var generalConfig = require('../config/generalConfig');
module.exports = function(sequelize, DataTypes) {

    var workout_type = sequelize.define('workout_type_model', 
        {
            id: {
                type: DataTypes.INTEGER,
                allowNull: false,
                primaryKey: true,
                autoIncrement: true
            },
            workout_name: DataTypes.STRING,
            description: DataTypes.TEXT,
            status: DataTypes.BOOLEAN,
            deletedAt: DataTypes.DATE
        }, 
        {
            freezeTableName: true,
            tableName: generalConfig.table_prefix + 'workout_type',
            classMethods: {
                associate: function(models) {
                    workout_type.hasMany(models.session, {
                        foreignKey: 'workout_type'
                    }),
                    workout_type.hasMany(models.coaching_criteria, {
                        foreignKey: 'workout_type_id'
                    })
                }
            }
        }
    );

    return workout_type;
};
