var generalConfig = require('../config/generalConfig');
module.exports = function(sequelize, DataTypes) {

    var user = sequelize.define('user', 
        {
            id: {
                type: DataTypes.INTEGER,
                allowNull: false,
                primaryKey: true,
                autoIncrement: true
            },
            email: DataTypes.STRING,
            password: DataTypes.STRING,
            firstname: DataTypes.STRING,
            lastname: DataTypes.STRING,
            profile_image: DataTypes.STRING,
            mobile_no: DataTypes.STRING,
            active: DataTypes.BOOLEAN,
            is_admin: DataTypes.BOOLEAN,
            is_fb_user: DataTypes.BOOLEAN,
            fb_id: DataTypes.STRING,
            emailverificationtoken: DataTypes.STRING,
            usertoken: DataTypes.STRING,
            deletedAt: DataTypes.DATE
        }, 
        {
            freezeTableName: true,
            tableName: generalConfig.table_prefix + 'users',
            classMethods: {
                associate: function(models) {
                    user.hasMany(models.rider, {
                        foreignKey: 'trainer_id'
                    }),
                    user.hasMany(models.session, {
                        foreignKey: 'trainer_id'
                    })
                }
            }
        }
    );

    return user;
};
