var generalConfig = require('../config/generalConfig');
module.exports = function(sequelize, DataTypes) {

    var sprint = sequelize.define('sprint', 
        {
            sprint_id: {
                type: DataTypes.INTEGER,
                allowNull: false,
                primaryKey: true,
                autoIncrement: true
            },
            session_id: DataTypes.INTEGER,
            sprint_start_time: "",
            sprint_end_time: "",
            ST: DataTypes.DECIMAL,
            RT: DataTypes.DECIMAL,
            distance_30: DataTypes.DECIMAL,
            distance_50: DataTypes.DECIMAL,
            distance_100: DataTypes.DECIMAL,
            status: DataTypes.BOOLEAN,
            deletedAt: DataTypes.DATE
        }, 
        {
            freezeTableName: true,
            tableName: generalConfig.table_prefix + 'sprints',
            classMethods: {
                associate: function(models) {
                    sprint.belongsTo(models.session, {
                        foreignKey: 'session_id'                        
                    })
                }
            }
        }
    );

    return sprint;
};
