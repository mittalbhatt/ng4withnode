var generalConfig = require('../config/generalConfig');
module.exports = function(sequelize, DataTypes) {

    var rider = sequelize.define('rider', 
        {
            rider_id: {
                type: DataTypes.INTEGER,
                allowNull: false,
                primaryKey: true,
                autoIncrement: true
            },
            trainer_id: DataTypes.INTEGER,
            firstname: DataTypes.STRING,
            lastname: DataTypes.STRING,
            email: DataTypes.STRING,
            profile_image: DataTypes.STRING,
            mobile_no: DataTypes.STRING,
            height: DataTypes.FLOAT,
            weight: DataTypes.FLOAT,
            age: DataTypes.INTEGER,
            active: DataTypes.BOOLEAN,
            deletedAt: DataTypes.DATE
                
        }, 
        {
            freezeTableName: true,
            tableName: generalConfig.table_prefix + 'riders',
            classMethods: {
                associate: function(models) {
                    rider.belongsTo(models.user, {
                        foreignKey: 'trainer_id',
                        as: 'trainer_details'                        
                    }),
                    rider.hasMany(models.session, {
                        foreignKey: 'rider_id'
                    })
                }
            }
        }
    );

    return rider;
};
