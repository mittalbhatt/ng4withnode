var generalConfig = require('../config/generalConfig');
module.exports = function(sequelize, DataTypes) {

    var session = sequelize.define('session', 
        {
            session_id: {
                type: DataTypes.INTEGER,
                allowNull: false,
                primaryKey: true,
                autoIncrement: true
            },
            session_start_date: "",
            session_end_date: "",
            workout_type: DataTypes.INTEGER,
            max_distance: DataTypes.STRING,
            trainer_id: DataTypes.INTEGER,
            rider_id: DataTypes.INTEGER,
            measurement_unit: DataTypes.STRING,
            status: DataTypes.BOOLEAN,
            deletedAt: DataTypes.DATE
        }, 
        {
            freezeTableName: true,
            tableName: generalConfig.table_prefix + 'sessions',
            classMethods: {
                associate: function(models) {
                    session.belongsTo(models.user, {
                        foreignKey: 'trainer_id'                        
                    }),
                    session.belongsTo(models.workout_type_model, {
                        foreignKey: 'workout_type'                        
                    }),
                    session.belongsTo(models.rider, {
                        foreignKey: 'rider_id'                        
                    }),
                    session.hasMany(models.sprint, {
                        foreignKey: 'session_id'
                    })
                }
            }
        }
    );

    return session;
};
